import { com_mendix_widget_native_slider_Slider as Slider } from "./slider";
/*

DISCLAIMER:
Do not change this file because it is core styling.
Customizing core files will make updating Atlas much more difficult in the future.
To customize any core styling, copy the part you want to customize to styles/native/app/ so the core styling is overwritten.

==========================================================================
    Range Slider

    Default Class For Mendix Range Slider Widget
========================================================================== */
export const com_mendix_widget_native_rangeslider_RangeSlider = Slider;
