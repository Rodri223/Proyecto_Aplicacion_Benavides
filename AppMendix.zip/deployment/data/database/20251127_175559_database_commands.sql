ALTER TABLE "myfirstmodule$archivos" DROP CONSTRAINT "frn_myfirstmodule$archivos_myfirstmodule$archivos_consulta";
DROP INDEX "idx_myfirstmodule$archivos_myfirstmodule$archivos_consulta";
ALTER TABLE "myfirstmodule$archivos" DROP COLUMN "myfirstmodule$archivos_consulta";
DELETE FROM "mendixsystem$association"  WHERE "id" = 'b362bad6-fd1e-4a6d-ac55-c6425777749a';
DELETE FROM "mendixsystem$index"  WHERE "id" = 'ea1f17ff-dc4d-3c73-aad9-fcfc20187aa5';
DELETE FROM "mendixsystem$index_column"  WHERE "index_id" = 'ea1f17ff-dc4d-3c73-aad9-fcfc20187aa5';
UPDATE "mendixsystem$version" SET "versionnumber" = '4.2', "lastsyncdate" = '20251127 17:55:58';
