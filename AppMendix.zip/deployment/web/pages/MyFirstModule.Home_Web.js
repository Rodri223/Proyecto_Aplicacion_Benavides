import { createElement } from "react";
const React = { createElement };

import { PageFragment } from "mendix/PageFragment";
import { ActionProperty } from "mendix/ActionProperty";
import { DatabaseObjectListProperty } from "mendix/DatabaseObjectListProperty";
import { ExpressionProperty } from "mendix/ExpressionProperty";
import { ListAttributeProperty } from "mendix/ListAttributeProperty";
import { TemplatedWidgetProperty } from "mendix/TemplatedWidgetProperty";
import { TextProperty } from "mendix/TextProperty";
import { WebIconProperty } from "mendix/WebIconProperty";

import { ActionButton } from "mendix/widgets/web/ActionButton";
import { Container } from "mendix/widgets/web/Container";
import { Div } from "mendix/widgets/web/Div";
import { ListView } from "mendix/widgets/web/ListView";
import { Text } from "mendix/widgets/web/Text";
import { addEnumerations, asPluginWidgets, t } from "mendix";

import { content as parentContent } from "../layouts/Atlas_Core.Atlas_Default.js";

const { $Container, $Div, $Text, $ActionButton, $ListView } = asPluginWidgets({ Container, Div, Text, ActionButton, ListView });

const region$Main = (historyId) => (<PageFragment renderKey={historyId}>{[
    <$Container key="p19.MyFirstModule.Home_Web.container1"
        $widgetId="p19.MyFirstModule.Home_Web.container1"
        class={"mx-name-container1 pageheader"}
        style={undefined}
        renderMode={"div"}
        onClick={undefined}
        content={[
            <$Div key="p19.MyFirstModule.Home_Web.layoutGrid2"
                $widgetId="p19.MyFirstModule.Home_Web.layoutGrid2"
                class={"mx-name-layoutGrid2 mx-layoutgrid mx-layoutgrid-fluid container-fluid"}
                style={undefined}
                content={[
                    <$Div key="p19.MyFirstModule.Home_Web.layoutGrid2$row0"
                        $widgetId="p19.MyFirstModule.Home_Web.layoutGrid2$row0"
                        class={"row"}
                        style={undefined}
                        content={[
                            <$Div key="p19.MyFirstModule.Home_Web.layoutGrid2$row0$column0"
                                $widgetId="p19.MyFirstModule.Home_Web.layoutGrid2$row0$column0"
                                class={"col-lg col-md col"}
                                style={undefined}
                                content={[
                                    <$Text key="p19.MyFirstModule.Home_Web.text1"
                                        $widgetId="p19.MyFirstModule.Home_Web.text1"
                                        class={"mx-name-text1 pageheader-title spacing-outer-bottom-large"}
                                        style={undefined}
                                        caption={t([
                                            ExpressionProperty({
                                                "expression": { "expr": { "type": "literal", "value": "Historial Medico" }, "args": {} }
                                            })
                                        ])}
                                        renderMode={"h1"} />
                                ]} />
                        ]} />,
                    <$Div key="p19.MyFirstModule.Home_Web.layoutGrid2$row1"
                        $widgetId="p19.MyFirstModule.Home_Web.layoutGrid2$row1"
                        class={"row"}
                        style={undefined}
                        content={[
                            <$Div key="p19.MyFirstModule.Home_Web.layoutGrid2$row1$column0"
                                $widgetId="p19.MyFirstModule.Home_Web.layoutGrid2$row1$column0"
                                class={"col-lg col-md col align-self-center"}
                                style={undefined}
                                content={[
                                    <$ActionButton key="p19.MyFirstModule.Home_Web.actionButton1"
                                        $widgetId="p19.MyFirstModule.Home_Web.actionButton1"
                                        buttonId={"p19.MyFirstModule.Home_Web.actionButton1"}
                                        class={"mx-name-actionButton1 pull-left btn-block"}
                                        style={undefined}
                                        tabIndex={undefined}
                                        renderType={"button"}
                                        role={undefined}
                                        buttonClass={"btn-danger"}
                                        caption={t([
                                            ExpressionProperty({
                                                "expression": { "expr": { "type": "literal", "value": "Agregar Antecedente" }, "args": {} }
                                            })
                                        ])}
                                        tooltip={TextProperty({
                                            "value": t([
                                                ""
                                            ])
                                        })}
                                        icon={WebIconProperty({
                                            "icon": { "type": "icon", "iconClass": "mx-icon-lined mx-icon-add" }
                                        })}
                                        action={ActionProperty({
                                            "action": { "type": "createObject", "argMap": {}, "config": { "entity": "MyFirstModule.Antecedente", "operationId": "+I1E4pSKEFqYl6sKWWC9Tg", "pageSettings": { "name": "MyFirstModule/Antecedente_NewEdit.page.xml", "location": "modal", "resizable": true }, "objectParameter": "param$Antecedente" }, "disabledDuringExecution": true },
                                            "abortOnServerValidation": true
                                        })} />
                                ]} />,
                            <$Div key="p19.MyFirstModule.Home_Web.layoutGrid2$row1$column1"
                                $widgetId="p19.MyFirstModule.Home_Web.layoutGrid2$row1$column1"
                                class={"col-lg col-md col"}
                                style={undefined}
                                content={undefined} />,
                            <$Div key="p19.MyFirstModule.Home_Web.layoutGrid2$row1$column2"
                                $widgetId="p19.MyFirstModule.Home_Web.layoutGrid2$row1$column2"
                                class={"col-lg col-md col"}
                                style={undefined}
                                content={undefined} />,
                            <$Div key="p19.MyFirstModule.Home_Web.layoutGrid2$row1$column3"
                                $widgetId="p19.MyFirstModule.Home_Web.layoutGrid2$row1$column3"
                                class={"col-lg col-md col"}
                                style={undefined}
                                content={undefined} />
                        ]} />
                ]} />,
            <$Div key="p19.MyFirstModule.Home_Web.layoutGrid4"
                $widgetId="p19.MyFirstModule.Home_Web.layoutGrid4"
                class={"mx-name-layoutGrid4 mx-layoutgrid mx-layoutgrid-fluid container-fluid"}
                style={undefined}
                content={[
                    <$Div key="p19.MyFirstModule.Home_Web.layoutGrid4$row0"
                        $widgetId="p19.MyFirstModule.Home_Web.layoutGrid4$row0"
                        class={"row"}
                        style={undefined}
                        content={[
                            <$Div key="p19.MyFirstModule.Home_Web.layoutGrid4$row0$column0"
                                $widgetId="p19.MyFirstModule.Home_Web.layoutGrid4$row0$column0"
                                class={"col-lg col-md col"}
                                style={undefined}
                                content={[
                                    <$Text key="p19.MyFirstModule.Home_Web.text3"
                                        $widgetId="p19.MyFirstModule.Home_Web.text3"
                                        class={"mx-name-text3"}
                                        style={undefined}
                                        caption={t([
                                            ExpressionProperty({
                                                "expression": { "expr": { "type": "literal", "value": "Alergias" }, "args": {} }
                                            })
                                        ])}
                                        renderMode={"h3"} />,
                                    <$ListView key="p19.MyFirstModule.Home_Web.listView1"
                                        $widgetId="p19.MyFirstModule.Home_Web.listView1"
                                        class={"mx-name-listView1"}
                                        style={undefined}
                                        listValue={DatabaseObjectListProperty({
                                            "dataSourceId": "p19.2",
                                            "entity": "MyFirstModule.Alergias",
                                            "operationId": "w0znGwk6MlSRUcF6uKboTw",
                                            "sort": []
                                        })}
                                        searchAttributes={[
                                            ListAttributeProperty({
                                                "path": "",
                                                "entity": "MyFirstModule.Alergias",
                                                "attribute": "Titulo",
                                                "attributeType": "String",
                                                "sortable": true,
                                                "filterable": true,
                                                "dataSourceId": "p19.2",
                                                "isList": false
                                            }),
                                            ListAttributeProperty({
                                                "path": "",
                                                "entity": "MyFirstModule.Alergias",
                                                "attribute": "Tipo",
                                                "attributeType": "String",
                                                "sortable": true,
                                                "filterable": true,
                                                "dataSourceId": "p19.2",
                                                "isList": false
                                            }),
                                            ListAttributeProperty({
                                                "path": "",
                                                "entity": "MyFirstModule.Alergias",
                                                "attribute": "Reaccion",
                                                "attributeType": "String",
                                                "sortable": true,
                                                "filterable": true,
                                                "dataSourceId": "p19.2",
                                                "isList": false
                                            }),
                                            ListAttributeProperty({
                                                "path": "",
                                                "entity": "MyFirstModule.Alergias",
                                                "attribute": "Descripcion",
                                                "attributeType": "String",
                                                "sortable": true,
                                                "filterable": true,
                                                "dataSourceId": "p19.2",
                                                "isList": false
                                            })
                                        ]}
                                        itemTemplate={TemplatedWidgetProperty({
                                            "dataSourceId": "p19.2",
                                            "editable": false,
                                            "children": () => [
                                                <$Container key="p19.MyFirstModule.Home_Web.container2"
                                                    $widgetId="p19.MyFirstModule.Home_Web.container2"
                                                    class={"mx-name-container2"}
                                                    style={undefined}
                                                    renderMode={"div"}
                                                    onClick={undefined}
                                                    content={[
                                                        <$Text key="p19.MyFirstModule.Home_Web.text2"
                                                            $widgetId="p19.MyFirstModule.Home_Web.text2"
                                                            class={"mx-name-text2"}
                                                            style={undefined}
                                                            caption={t([
                                                                ExpressionProperty({
                                                                    "expression": { "expr": { "type": "function", "name": "+", "parameters": [ { "type": "function", "name": "+", "parameters": [ { "type": "variable", "variable": "currentObject", "path": "Titulo" }, { "type": "literal", "value": " - Reaccion: " } ] }, { "type": "variable", "variable": "currentObject", "path": "Reaccion" } ] }, "args": { "currentObject": { "widget": "p19.MyFirstModule.Home_Web.listView1", "source": "object" } } }
                                                                })
                                                            ])}
                                                            renderMode={"span"} />,
                                                        <$ActionButton key="p19.MyFirstModule.Home_Web.actionButton2"
                                                            $widgetId="p19.MyFirstModule.Home_Web.actionButton2"
                                                            buttonId={"p19.MyFirstModule.Home_Web.actionButton2"}
                                                            class={"mx-name-actionButton2 pull-right"}
                                                            style={undefined}
                                                            tabIndex={undefined}
                                                            renderType={"link"}
                                                            role={"button"}
                                                            buttonClass={"btn-default"}
                                                            caption={t([
                                                                ExpressionProperty({
                                                                    "expression": { "expr": { "type": "literal", "value": "" }, "args": {} }
                                                                })
                                                            ])}
                                                            tooltip={TextProperty({
                                                                "value": t([
                                                                    "Menu Right Icon"
                                                                ])
                                                            })}
                                                            icon={WebIconProperty({
                                                                "icon": { "type": "icon", "iconClass": "mx-icon-lined mx-icon-chevron-right" }
                                                            })}
                                                            action={ActionProperty({
                                                                "action": { "type": "openPage", "argMap": { "param$Alergias": { "widget": "p19.MyFirstModule.Home_Web.listView1", "source": "object" } }, "config": { "name": "MyFirstModule/Alergias_View.page.xml", "location": "modal", "resizable": true }, "disabledDuringExecution": true },
                                                                "abortOnServerValidation": true
                                                            })} />
                                                    ]}
                                                    ariaHidden={false} />
                                            ]
                                        })}
                                        onClick={undefined}
                                        pageSize={10} />
                                ]} />,
                            <$Div key="p19.MyFirstModule.Home_Web.layoutGrid4$row0$column1"
                                $widgetId="p19.MyFirstModule.Home_Web.layoutGrid4$row0$column1"
                                class={"col-lg col-md col"}
                                style={undefined}
                                content={[
                                    <$Text key="p19.MyFirstModule.Home_Web.text4"
                                        $widgetId="p19.MyFirstModule.Home_Web.text4"
                                        class={"mx-name-text4"}
                                        style={undefined}
                                        caption={t([
                                            ExpressionProperty({
                                                "expression": { "expr": { "type": "literal", "value": "Historial de Anotaciones" }, "args": {} }
                                            })
                                        ])}
                                        renderMode={"h3"} />,
                                    <$ListView key="p19.MyFirstModule.Home_Web.listView2"
                                        $widgetId="p19.MyFirstModule.Home_Web.listView2"
                                        class={"mx-name-listView2"}
                                        style={undefined}
                                        listValue={DatabaseObjectListProperty({
                                            "dataSourceId": "p19.5",
                                            "entity": "MyFirstModule.Anotaciones",
                                            "operationId": "y8K58Yj7zFuGy6LASLNqrA",
                                            "sort": []
                                        })}
                                        searchAttributes={[
                                            ListAttributeProperty({
                                                "path": "",
                                                "entity": "MyFirstModule.Anotaciones",
                                                "attribute": "Titulo",
                                                "attributeType": "String",
                                                "sortable": true,
                                                "filterable": true,
                                                "dataSourceId": "p19.5",
                                                "isList": false
                                            }),
                                            ListAttributeProperty({
                                                "path": "",
                                                "entity": "MyFirstModule.Anotaciones",
                                                "attribute": "Descripcion",
                                                "attributeType": "String",
                                                "sortable": true,
                                                "filterable": true,
                                                "dataSourceId": "p19.5",
                                                "isList": false
                                            })
                                        ]}
                                        itemTemplate={TemplatedWidgetProperty({
                                            "dataSourceId": "p19.5",
                                            "editable": false,
                                            "children": () => [
                                                <$Div key="p19.MyFirstModule.Home_Web.layoutGrid1"
                                                    $widgetId="p19.MyFirstModule.Home_Web.layoutGrid1"
                                                    class={"mx-name-layoutGrid1 mx-layoutgrid mx-layoutgrid-fluid"}
                                                    style={undefined}
                                                    content={[
                                                        <$Div key="p19.MyFirstModule.Home_Web.layoutGrid1$row0"
                                                            $widgetId="p19.MyFirstModule.Home_Web.layoutGrid1$row0"
                                                            class={"row"}
                                                            style={undefined}
                                                            content={[
                                                                <$Div key="p19.MyFirstModule.Home_Web.layoutGrid1$row0$column0"
                                                                    $widgetId="p19.MyFirstModule.Home_Web.layoutGrid1$row0$column0"
                                                                    class={"col-lg-9 col-md col"}
                                                                    style={undefined}
                                                                    content={[
                                                                        <$Text key="p19.MyFirstModule.Home_Web.text5"
                                                                            $widgetId="p19.MyFirstModule.Home_Web.text5"
                                                                            class={"mx-name-text5"}
                                                                            style={undefined}
                                                                            caption={t([
                                                                                ExpressionProperty({
                                                                                    "expression": { "expr": { "type": "function", "name": "+", "parameters": [ { "type": "function", "name": "+", "parameters": [ { "type": "function", "name": "+", "parameters": [ { "type": "function", "name": "+", "parameters": [ { "type": "variable", "variable": "currentObject", "path": "Titulo" }, { "type": "literal", "value": " - " } ] }, { "type": "variable", "variable": "currentObject", "path": "Descripcion" } ] }, { "type": "literal", "value": "\r\nFecha: " } ] }, { "type": "function", "name": "_format", "parameters": [ { "type": "variable", "variable": "currentObject", "path": "FechaAnotacion" }, { "type": "literal", "value": "{\"type\":\"date\"}" } ] } ] }, "args": { "currentObject": { "widget": "p19.MyFirstModule.Home_Web.listView2", "source": "object" } } }
                                                                                })
                                                                            ])}
                                                                            renderMode={"span"} />
                                                                    ]} />,
                                                                <$Div key="p19.MyFirstModule.Home_Web.layoutGrid1$row0$column1"
                                                                    $widgetId="p19.MyFirstModule.Home_Web.layoutGrid1$row0$column1"
                                                                    class={"col-lg-3 col-md col align-self-center"}
                                                                    style={undefined}
                                                                    content={[
                                                                        <$ActionButton key="p19.MyFirstModule.Home_Web.actionButton3"
                                                                            $widgetId="p19.MyFirstModule.Home_Web.actionButton3"
                                                                            buttonId={"p19.MyFirstModule.Home_Web.actionButton3"}
                                                                            class={"mx-name-actionButton3 pull-right"}
                                                                            style={undefined}
                                                                            tabIndex={undefined}
                                                                            renderType={"link"}
                                                                            role={"button"}
                                                                            buttonClass={"btn-default"}
                                                                            caption={t([
                                                                                ExpressionProperty({
                                                                                    "expression": { "expr": { "type": "literal", "value": "" }, "args": {} }
                                                                                })
                                                                            ])}
                                                                            tooltip={TextProperty({
                                                                                "value": t([
                                                                                    "Menu Right Icon"
                                                                                ])
                                                                            })}
                                                                            icon={WebIconProperty({
                                                                                "icon": { "type": "icon", "iconClass": "mx-icon-lined mx-icon-chevron-right" }
                                                                            })}
                                                                            action={ActionProperty({
                                                                                "action": { "type": "openPage", "argMap": { "param$Anotaciones": { "widget": "p19.MyFirstModule.Home_Web.listView2", "source": "object" } }, "config": { "name": "MyFirstModule/Anotaciones_View.page.xml", "location": "modal", "resizable": true }, "disabledDuringExecution": true },
                                                                                "abortOnServerValidation": true
                                                                            })} />
                                                                    ]} />
                                                            ]} />
                                                    ]} />
                                            ]
                                        })}
                                        onClick={undefined}
                                        pageSize={10} />
                                ]} />
                        ]} />,
                    <$Div key="p19.MyFirstModule.Home_Web.layoutGrid4$row1"
                        $widgetId="p19.MyFirstModule.Home_Web.layoutGrid4$row1"
                        class={"row"}
                        style={undefined}
                        content={[
                            <$Div key="p19.MyFirstModule.Home_Web.layoutGrid4$row1$column0"
                                $widgetId="p19.MyFirstModule.Home_Web.layoutGrid4$row1$column0"
                                class={"col-lg col-md col"}
                                style={undefined}
                                content={[
                                    <$Text key="p19.MyFirstModule.Home_Web.text6"
                                        $widgetId="p19.MyFirstModule.Home_Web.text6"
                                        class={"mx-name-text6 spacing-outer-top-medium"}
                                        style={undefined}
                                        caption={t([
                                            ExpressionProperty({
                                                "expression": { "expr": { "type": "literal", "value": "Historial de Consultas" }, "args": {} }
                                            })
                                        ])}
                                        renderMode={"h3"} />,
                                    <$ListView key="p19.MyFirstModule.Home_Web.listView3"
                                        $widgetId="p19.MyFirstModule.Home_Web.listView3"
                                        class={"mx-name-listView3"}
                                        style={undefined}
                                        listValue={DatabaseObjectListProperty({
                                            "dataSourceId": "p19.8",
                                            "entity": "MyFirstModule.Consulta",
                                            "operationId": "MAGkRtnJi1CBKy+hlP/pqg",
                                            "sort": []
                                        })}
                                        searchAttributes={[
                                            ListAttributeProperty({
                                                "path": "",
                                                "entity": "MyFirstModule.Consulta",
                                                "attribute": "Paciente",
                                                "attributeType": "String",
                                                "sortable": true,
                                                "filterable": true,
                                                "dataSourceId": "p19.8",
                                                "isList": false
                                            }),
                                            ListAttributeProperty({
                                                "path": "",
                                                "entity": "MyFirstModule.Consulta",
                                                "attribute": "Medico",
                                                "attributeType": "String",
                                                "sortable": true,
                                                "filterable": true,
                                                "dataSourceId": "p19.8",
                                                "isList": false
                                            }),
                                            ListAttributeProperty({
                                                "path": "",
                                                "entity": "MyFirstModule.Consulta",
                                                "attribute": "Motivo",
                                                "attributeType": "String",
                                                "sortable": true,
                                                "filterable": true,
                                                "dataSourceId": "p19.8",
                                                "isList": false
                                            })
                                        ]}
                                        itemTemplate={TemplatedWidgetProperty({
                                            "dataSourceId": "p19.8",
                                            "editable": false,
                                            "children": () => [
                                                <$Div key="p19.MyFirstModule.Home_Web.layoutGrid6"
                                                    $widgetId="p19.MyFirstModule.Home_Web.layoutGrid6"
                                                    class={"mx-name-layoutGrid6 mx-layoutgrid mx-layoutgrid-fluid"}
                                                    style={undefined}
                                                    content={[
                                                        <$Div key="p19.MyFirstModule.Home_Web.layoutGrid6$row0"
                                                            $widgetId="p19.MyFirstModule.Home_Web.layoutGrid6$row0"
                                                            class={"row"}
                                                            style={undefined}
                                                            content={[
                                                                <$Div key="p19.MyFirstModule.Home_Web.layoutGrid6$row0$column0"
                                                                    $widgetId="p19.MyFirstModule.Home_Web.layoutGrid6$row0$column0"
                                                                    class={"col-lg-9 col-md col"}
                                                                    style={undefined}
                                                                    content={[
                                                                        <$Text key="p19.MyFirstModule.Home_Web.text7"
                                                                            $widgetId="p19.MyFirstModule.Home_Web.text7"
                                                                            class={"mx-name-text7"}
                                                                            style={undefined}
                                                                            caption={t([
                                                                                ExpressionProperty({
                                                                                    "expression": { "expr": { "type": "function", "name": "+", "parameters": [ { "type": "function", "name": "+", "parameters": [ { "type": "function", "name": "+", "parameters": [ { "type": "function", "name": "+", "parameters": [ { "type": "function", "name": "+", "parameters": [ { "type": "literal", "value": "Medico: " }, { "type": "variable", "variable": "currentObject", "path": "Medico" } ] }, { "type": "literal", "value": "\r\nMotivo: " } ] }, { "type": "variable", "variable": "currentObject", "path": "Motivo" } ] }, { "type": "literal", "value": "\r\nFecha: " } ] }, { "type": "function", "name": "_format", "parameters": [ { "type": "variable", "variable": "currentObject", "path": "FechaConsulta" }, { "type": "literal", "value": "{\"type\":\"date\"}" } ] } ] }, "args": { "currentObject": { "widget": "p19.MyFirstModule.Home_Web.listView3", "source": "object" } } }
                                                                                })
                                                                            ])}
                                                                            renderMode={"span"} />
                                                                    ]} />,
                                                                <$Div key="p19.MyFirstModule.Home_Web.layoutGrid6$row0$column1"
                                                                    $widgetId="p19.MyFirstModule.Home_Web.layoutGrid6$row0$column1"
                                                                    class={"col-lg-3 col-md col align-self-center"}
                                                                    style={undefined}
                                                                    content={[
                                                                        <$ActionButton key="p19.MyFirstModule.Home_Web.actionButton4"
                                                                            $widgetId="p19.MyFirstModule.Home_Web.actionButton4"
                                                                            buttonId={"p19.MyFirstModule.Home_Web.actionButton4"}
                                                                            class={"mx-name-actionButton4 pull-right"}
                                                                            style={undefined}
                                                                            tabIndex={undefined}
                                                                            renderType={"link"}
                                                                            role={"button"}
                                                                            buttonClass={"btn-default"}
                                                                            caption={t([
                                                                                ExpressionProperty({
                                                                                    "expression": { "expr": { "type": "literal", "value": "" }, "args": {} }
                                                                                })
                                                                            ])}
                                                                            tooltip={TextProperty({
                                                                                "value": t([
                                                                                    ""
                                                                                ])
                                                                            })}
                                                                            icon={WebIconProperty({
                                                                                "icon": { "type": "icon", "iconClass": "mx-icon-lined mx-icon-chevron-right" }
                                                                            })}
                                                                            action={ActionProperty({
                                                                                "action": { "type": "openPage", "argMap": { "param$Consulta": { "widget": "p19.MyFirstModule.Home_Web.listView3", "source": "object" } }, "config": { "name": "MyFirstModule/Consulta_View.page.xml", "location": "modal", "resizable": true }, "disabledDuringExecution": true },
                                                                                "abortOnServerValidation": true
                                                                            })} />
                                                                    ]} />
                                                            ]} />
                                                    ]} />
                                            ]
                                        })}
                                        onClick={undefined}
                                        pageSize={10} />
                                ]} />,
                            <$Div key="p19.MyFirstModule.Home_Web.layoutGrid4$row1$column1"
                                $widgetId="p19.MyFirstModule.Home_Web.layoutGrid4$row1$column1"
                                class={"col-lg col-md col"}
                                style={undefined}
                                content={[
                                    <$Text key="p19.MyFirstModule.Home_Web.text8"
                                        $widgetId="p19.MyFirstModule.Home_Web.text8"
                                        class={"mx-name-text8 spacing-outer-top-medium"}
                                        style={undefined}
                                        caption={t([
                                            ExpressionProperty({
                                                "expression": { "expr": { "type": "literal", "value": "Historial de Recetas" }, "args": {} }
                                            })
                                        ])}
                                        renderMode={"h3"} />,
                                    <$ListView key="p19.MyFirstModule.Home_Web.listView4"
                                        $widgetId="p19.MyFirstModule.Home_Web.listView4"
                                        class={"mx-name-listView4"}
                                        style={undefined}
                                        listValue={DatabaseObjectListProperty({
                                            "dataSourceId": "p19.11",
                                            "entity": "MyFirstModule.Receta",
                                            "operationId": "00o9ILgg5l+onoxM/TMq3g",
                                            "sort": []
                                        })}
                                        searchAttributes={[
                                            ListAttributeProperty({
                                                "path": "",
                                                "entity": "MyFirstModule.Receta",
                                                "attribute": "Medico",
                                                "attributeType": "String",
                                                "sortable": true,
                                                "filterable": true,
                                                "dataSourceId": "p19.11",
                                                "isList": false
                                            }),
                                            ListAttributeProperty({
                                                "path": "",
                                                "entity": "MyFirstModule.Receta",
                                                "attribute": "Paciente",
                                                "attributeType": "String",
                                                "sortable": true,
                                                "filterable": true,
                                                "dataSourceId": "p19.11",
                                                "isList": false
                                            })
                                        ]}
                                        itemTemplate={TemplatedWidgetProperty({
                                            "dataSourceId": "p19.11",
                                            "editable": false,
                                            "children": () => [
                                                <$Div key="p19.MyFirstModule.Home_Web.layoutGrid5"
                                                    $widgetId="p19.MyFirstModule.Home_Web.layoutGrid5"
                                                    class={"mx-name-layoutGrid5 mx-layoutgrid mx-layoutgrid-fluid"}
                                                    style={undefined}
                                                    content={[
                                                        <$Div key="p19.MyFirstModule.Home_Web.layoutGrid5$row0"
                                                            $widgetId="p19.MyFirstModule.Home_Web.layoutGrid5$row0"
                                                            class={"row"}
                                                            style={undefined}
                                                            content={[
                                                                <$Div key="p19.MyFirstModule.Home_Web.layoutGrid5$row0$column0"
                                                                    $widgetId="p19.MyFirstModule.Home_Web.layoutGrid5$row0$column0"
                                                                    class={"col-lg-9 col-md col"}
                                                                    style={undefined}
                                                                    content={[
                                                                        <$Text key="p19.MyFirstModule.Home_Web.text9"
                                                                            $widgetId="p19.MyFirstModule.Home_Web.text9"
                                                                            class={"mx-name-text9"}
                                                                            style={undefined}
                                                                            caption={t([
                                                                                ExpressionProperty({
                                                                                    "expression": { "expr": { "type": "function", "name": "+", "parameters": [ { "type": "function", "name": "+", "parameters": [ { "type": "function", "name": "+", "parameters": [ { "type": "function", "name": "+", "parameters": [ { "type": "function", "name": "+", "parameters": [ { "type": "literal", "value": "Medico: " }, { "type": "variable", "variable": "currentObject", "path": "Medico" } ] }, { "type": "literal", "value": "\r\nFecha: " } ] }, { "type": "function", "name": "_format", "parameters": [ { "type": "variable", "variable": "currentObject", "path": "MyFirstModule.Receta_Consulta/MyFirstModule.Consulta/FechaConsulta" }, { "type": "literal", "value": "{\"type\":\"date\"}" } ] } ] }, { "type": "literal", "value": "\r\nReclamado: " } ] }, { "type": "function", "name": "_format", "parameters": [ { "type": "variable", "variable": "currentObject", "path": "Entregado" }, { "type": "literal", "value": "{}" } ] } ] }, "args": { "currentObject": { "widget": "p19.MyFirstModule.Home_Web.listView4", "source": "object" } } }
                                                                                })
                                                                            ])}
                                                                            renderMode={"span"} />
                                                                    ]} />,
                                                                <$Div key="p19.MyFirstModule.Home_Web.layoutGrid5$row0$column1"
                                                                    $widgetId="p19.MyFirstModule.Home_Web.layoutGrid5$row0$column1"
                                                                    class={"col-lg-3 col-md col align-self-center"}
                                                                    style={undefined}
                                                                    content={[
                                                                        <$ActionButton key="p19.MyFirstModule.Home_Web.actionButton5"
                                                                            $widgetId="p19.MyFirstModule.Home_Web.actionButton5"
                                                                            buttonId={"p19.MyFirstModule.Home_Web.actionButton5"}
                                                                            class={"mx-name-actionButton5 pull-right"}
                                                                            style={undefined}
                                                                            tabIndex={undefined}
                                                                            renderType={"link"}
                                                                            role={"button"}
                                                                            buttonClass={"btn-default"}
                                                                            caption={t([
                                                                                ExpressionProperty({
                                                                                    "expression": { "expr": { "type": "literal", "value": "" }, "args": {} }
                                                                                })
                                                                            ])}
                                                                            tooltip={TextProperty({
                                                                                "value": t([
                                                                                    ""
                                                                                ])
                                                                            })}
                                                                            icon={WebIconProperty({
                                                                                "icon": { "type": "icon", "iconClass": "mx-icon-lined mx-icon-chevron-right" }
                                                                            })}
                                                                            action={ActionProperty({
                                                                                "action": { "type": "openPage", "argMap": { "param$Receta": { "widget": "p19.MyFirstModule.Home_Web.listView4", "source": "object" } }, "config": { "name": "MyFirstModule/Receta_View.page.xml", "location": "modal", "resizable": true }, "disabledDuringExecution": true },
                                                                                "abortOnServerValidation": true
                                                                            })} />
                                                                    ]} />
                                                            ]} />
                                                    ]} />
                                            ]
                                        })}
                                        onClick={undefined}
                                        pageSize={10} />
                                ]} />
                        ]} />,
                    <$Div key="p19.MyFirstModule.Home_Web.layoutGrid4$row2"
                        $widgetId="p19.MyFirstModule.Home_Web.layoutGrid4$row2"
                        class={"row"}
                        style={undefined}
                        content={[
                            <$Div key="p19.MyFirstModule.Home_Web.layoutGrid4$row2$column0"
                                $widgetId="p19.MyFirstModule.Home_Web.layoutGrid4$row2$column0"
                                class={"col-lg col-md col"}
                                style={undefined}
                                content={[
                                    <$Text key="p19.MyFirstModule.Home_Web.text10"
                                        $widgetId="p19.MyFirstModule.Home_Web.text10"
                                        class={"mx-name-text10 spacing-outer-top-medium"}
                                        style={undefined}
                                        caption={t([
                                            ExpressionProperty({
                                                "expression": { "expr": { "type": "literal", "value": "Estudios y Resultados" }, "args": {} }
                                            })
                                        ])}
                                        renderMode={"h3"} />,
                                    <$ListView key="p19.MyFirstModule.Home_Web.listView6"
                                        $widgetId="p19.MyFirstModule.Home_Web.listView6"
                                        class={"mx-name-listView6"}
                                        style={undefined}
                                        listValue={DatabaseObjectListProperty({
                                            "dataSourceId": "p19.14",
                                            "entity": "MyFirstModule.Estudios",
                                            "operationId": "8jdxpiJLWVinwgKml0Iy4g",
                                            "sort": []
                                        })}
                                        searchAttributes={[
                                            ListAttributeProperty({
                                                "path": "",
                                                "entity": "MyFirstModule.Estudios",
                                                "attribute": "Titulo",
                                                "attributeType": "String",
                                                "sortable": true,
                                                "filterable": true,
                                                "dataSourceId": "p19.14",
                                                "isList": false
                                            }),
                                            ListAttributeProperty({
                                                "path": "",
                                                "entity": "MyFirstModule.Estudios",
                                                "attribute": "Interpretacion",
                                                "attributeType": "String",
                                                "sortable": true,
                                                "filterable": true,
                                                "dataSourceId": "p19.14",
                                                "isList": false
                                            })
                                        ]}
                                        itemTemplate={TemplatedWidgetProperty({
                                            "dataSourceId": "p19.14",
                                            "editable": false,
                                            "children": () => [
                                                <$Div key="p19.MyFirstModule.Home_Web.layoutGrid3"
                                                    $widgetId="p19.MyFirstModule.Home_Web.layoutGrid3"
                                                    class={"mx-name-layoutGrid3 mx-layoutgrid mx-layoutgrid-fluid"}
                                                    style={undefined}
                                                    content={[
                                                        <$Div key="p19.MyFirstModule.Home_Web.layoutGrid3$row0"
                                                            $widgetId="p19.MyFirstModule.Home_Web.layoutGrid3$row0"
                                                            class={"row"}
                                                            style={undefined}
                                                            content={[
                                                                <$Div key="p19.MyFirstModule.Home_Web.layoutGrid3$row0$column0"
                                                                    $widgetId="p19.MyFirstModule.Home_Web.layoutGrid3$row0$column0"
                                                                    class={"col-lg-9 col-md col"}
                                                                    style={undefined}
                                                                    content={[
                                                                        <$Text key="p19.MyFirstModule.Home_Web.text12"
                                                                            $widgetId="p19.MyFirstModule.Home_Web.text12"
                                                                            class={"mx-name-text12"}
                                                                            style={undefined}
                                                                            caption={t([
                                                                                ExpressionProperty({
                                                                                    "expression": { "expr": { "type": "function", "name": "+", "parameters": [ { "type": "function", "name": "+", "parameters": [ { "type": "function", "name": "+", "parameters": [ { "type": "function", "name": "+", "parameters": [ { "type": "function", "name": "+", "parameters": [ { "type": "variable", "variable": "currentObject", "path": "Titulo" }, { "type": "literal", "value": "\r\nInterpretación: " } ] }, { "type": "variable", "variable": "currentObject", "path": "Interpretacion" } ] }, { "type": "literal", "value": "\r\n(" } ] }, { "type": "function", "name": "_format", "parameters": [ { "type": "variable", "variable": "currentObject", "path": "FechaRealizacion" }, { "type": "literal", "value": "{\"type\":\"date\"}" } ] } ] }, { "type": "literal", "value": ")" } ] }, "args": { "currentObject": { "widget": "p19.MyFirstModule.Home_Web.listView6", "source": "object" } } }
                                                                                })
                                                                            ])}
                                                                            renderMode={"span"} />
                                                                    ]} />,
                                                                <$Div key="p19.MyFirstModule.Home_Web.layoutGrid3$row0$column1"
                                                                    $widgetId="p19.MyFirstModule.Home_Web.layoutGrid3$row0$column1"
                                                                    class={"col-lg-3 col-md col align-self-center"}
                                                                    style={undefined}
                                                                    content={[
                                                                        <$ActionButton key="p19.MyFirstModule.Home_Web.actionButton7"
                                                                            $widgetId="p19.MyFirstModule.Home_Web.actionButton7"
                                                                            buttonId={"p19.MyFirstModule.Home_Web.actionButton7"}
                                                                            class={"mx-name-actionButton7 pull-right"}
                                                                            style={undefined}
                                                                            tabIndex={undefined}
                                                                            renderType={"link"}
                                                                            role={"button"}
                                                                            buttonClass={"btn-default"}
                                                                            caption={t([
                                                                                ExpressionProperty({
                                                                                    "expression": { "expr": { "type": "literal", "value": "" }, "args": {} }
                                                                                })
                                                                            ])}
                                                                            tooltip={TextProperty({
                                                                                "value": t([
                                                                                    ""
                                                                                ])
                                                                            })}
                                                                            icon={WebIconProperty({
                                                                                "icon": { "type": "icon", "iconClass": "mx-icon-lined mx-icon-chevron-right" }
                                                                            })}
                                                                            action={ActionProperty({
                                                                                "action": { "type": "openPage", "argMap": { "param$Estudios": { "widget": "p19.MyFirstModule.Home_Web.listView6", "source": "object" } }, "config": { "name": "MyFirstModule/Estudios_View.page.xml", "location": "modal", "resizable": true }, "disabledDuringExecution": true },
                                                                                "abortOnServerValidation": true
                                                                            })} />
                                                                    ]} />
                                                            ]} />
                                                    ]} />
                                            ]
                                        })}
                                        onClick={undefined}
                                        pageSize={10} />
                                ]} />,
                            <$Div key="p19.MyFirstModule.Home_Web.layoutGrid4$row2$column1"
                                $widgetId="p19.MyFirstModule.Home_Web.layoutGrid4$row2$column1"
                                class={"col-lg col-md col"}
                                style={undefined}
                                content={[
                                    <$Text key="p19.MyFirstModule.Home_Web.text11"
                                        $widgetId="p19.MyFirstModule.Home_Web.text11"
                                        class={"mx-name-text11 spacing-outer-top-medium"}
                                        style={undefined}
                                        caption={t([
                                            ExpressionProperty({
                                                "expression": { "expr": { "type": "literal", "value": "Archivos" }, "args": {} }
                                            })
                                        ])}
                                        renderMode={"h3"} />,
                                    <$ListView key="p19.MyFirstModule.Home_Web.listView5"
                                        $widgetId="p19.MyFirstModule.Home_Web.listView5"
                                        class={"mx-name-listView5"}
                                        style={undefined}
                                        listValue={DatabaseObjectListProperty({
                                            "dataSourceId": "p19.17",
                                            "entity": "MyFirstModule.Archivos",
                                            "operationId": "Gr38UxiQSliBdSZSO//Bxw",
                                            "sort": []
                                        })}
                                        searchAttributes={[
                                            ListAttributeProperty({
                                                "path": "",
                                                "entity": "MyFirstModule.Archivos",
                                                "attribute": "Descripcion",
                                                "attributeType": "String",
                                                "sortable": true,
                                                "filterable": true,
                                                "dataSourceId": "p19.17",
                                                "isList": false
                                            }),
                                            ListAttributeProperty({
                                                "path": "",
                                                "entity": "MyFirstModule.Archivos",
                                                "attribute": "Name",
                                                "attributeType": "String",
                                                "sortable": true,
                                                "filterable": true,
                                                "dataSourceId": "p19.17",
                                                "isList": false
                                            }),
                                            ListAttributeProperty({
                                                "path": "",
                                                "entity": "MyFirstModule.Archivos",
                                                "attribute": "Size",
                                                "attributeType": "Long",
                                                "sortable": true,
                                                "filterable": true,
                                                "dataSourceId": "p19.17",
                                                "isList": false
                                            })
                                        ]}
                                        itemTemplate={TemplatedWidgetProperty({
                                            "dataSourceId": "p19.17",
                                            "editable": false,
                                            "children": () => [
                                                <$Div key="p19.MyFirstModule.Home_Web.layoutGrid7"
                                                    $widgetId="p19.MyFirstModule.Home_Web.layoutGrid7"
                                                    class={"mx-name-layoutGrid7 mx-layoutgrid mx-layoutgrid-fluid"}
                                                    style={undefined}
                                                    content={[
                                                        <$Div key="p19.MyFirstModule.Home_Web.layoutGrid7$row0"
                                                            $widgetId="p19.MyFirstModule.Home_Web.layoutGrid7$row0"
                                                            class={"row"}
                                                            style={undefined}
                                                            content={[
                                                                <$Div key="p19.MyFirstModule.Home_Web.layoutGrid7$row0$column0"
                                                                    $widgetId="p19.MyFirstModule.Home_Web.layoutGrid7$row0$column0"
                                                                    class={"col-lg-9 col-md col align-self-center"}
                                                                    style={undefined}
                                                                    content={[
                                                                        <$Text key="p19.MyFirstModule.Home_Web.text13"
                                                                            $widgetId="p19.MyFirstModule.Home_Web.text13"
                                                                            class={"mx-name-text13"}
                                                                            style={undefined}
                                                                            caption={t([
                                                                                ExpressionProperty({
                                                                                    "expression": { "expr": { "type": "function", "name": "+", "parameters": [ { "type": "function", "name": "+", "parameters": [ { "type": "function", "name": "+", "parameters": [ { "type": "variable", "variable": "currentObject", "path": "Name" }, { "type": "literal", "value": " - (" } ] }, { "type": "function", "name": "_format", "parameters": [ { "type": "variable", "variable": "currentObject", "path": "MyFirstModule.Archivos_Antecedente/MyFirstModule.Antecedente/FechaRegistro" }, { "type": "literal", "value": "{\"type\":\"date\"}" } ] } ] }, { "type": "literal", "value": ")" } ] }, "args": { "currentObject": { "widget": "p19.MyFirstModule.Home_Web.listView5", "source": "object" } } }
                                                                                })
                                                                            ])}
                                                                            renderMode={"span"} />
                                                                    ]} />,
                                                                <$Div key="p19.MyFirstModule.Home_Web.layoutGrid7$row0$column1"
                                                                    $widgetId="p19.MyFirstModule.Home_Web.layoutGrid7$row0$column1"
                                                                    class={"col-lg-3 col-md col align-self-center"}
                                                                    style={undefined}
                                                                    content={[
                                                                        <$ActionButton key="p19.MyFirstModule.Home_Web.actionButton6"
                                                                            $widgetId="p19.MyFirstModule.Home_Web.actionButton6"
                                                                            buttonId={"p19.MyFirstModule.Home_Web.actionButton6"}
                                                                            class={"mx-name-actionButton6 pull-right"}
                                                                            style={undefined}
                                                                            tabIndex={undefined}
                                                                            renderType={"link"}
                                                                            role={"button"}
                                                                            buttonClass={"btn-default"}
                                                                            caption={t([
                                                                                ExpressionProperty({
                                                                                    "expression": { "expr": { "type": "literal", "value": "" }, "args": {} }
                                                                                })
                                                                            ])}
                                                                            tooltip={TextProperty({
                                                                                "value": t([
                                                                                    ""
                                                                                ])
                                                                            })}
                                                                            icon={WebIconProperty({
                                                                                "icon": { "type": "icon", "iconClass": "mx-icon-lined mx-icon-chevron-right" }
                                                                            })}
                                                                            action={ActionProperty({
                                                                                "action": { "type": "openPage", "argMap": { "param$Archivos": { "widget": "p19.MyFirstModule.Home_Web.listView5", "source": "object" } }, "config": { "name": "MyFirstModule/Archivos_View.page.xml", "location": "modal", "resizable": true }, "disabledDuringExecution": true },
                                                                                "abortOnServerValidation": true
                                                                            })} />
                                                                    ]} />
                                                            ]} />
                                                    ]} />
                                            ]
                                        })}
                                        onClick={undefined}
                                        pageSize={10} />
                                ]} />
                        ]} />
                ]} />
        ]}
        ariaHidden={false} />
]}</PageFragment>);

export const title = t([
    "Homepage"
]);

export const classes = "layout-atlas layout-atlas-responsive-default";

export const style = {};
export const content = { ...parentContent,
    "Atlas_Core.Atlas_Default.Main": region$Main,
};
