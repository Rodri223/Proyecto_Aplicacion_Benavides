import { createElement } from "react";
const React = { createElement };

import { PageFragment } from "mendix/PageFragment";
import { ActionProperty } from "mendix/ActionProperty";
import { AssociationObjectProperty } from "mendix/AssociationObjectProperty";
import { AttributeProperty } from "mendix/AttributeProperty";
import { DerivedUniqueIdProperty } from "mendix/DerivedUniqueIdProperty";
import { ExpressionProperty } from "mendix/ExpressionProperty";
import { TextProperty } from "mendix/TextProperty";
import { ValidationProperty } from "mendix/ValidationProperty";

import { ActionButton } from "mendix/widgets/web/ActionButton";
import { DataView } from "mendix/widgets/web/DataView";
import { Div } from "mendix/widgets/web/Div";
import { FormGroup } from "mendix/widgets/web/FormGroup";
import { TextBox } from "mendix/widgets/web/TextBox";
import { addEnumerations, asPluginWidgets, t } from "mendix";

import { content as parentContent } from "../layouts/Atlas_Core.PopupLayout.js";

const { $Div, $DataView, $FormGroup, $TextBox, $ActionButton } = asPluginWidgets({ Div, DataView, FormGroup, TextBox, ActionButton });

const region$Main = (historyId) => (<PageFragment renderKey={historyId}>{[
    <$Div key="p26.MyFirstModule.Alergia_NewEdit2.layoutGrid1"
        $widgetId="p26.MyFirstModule.Alergia_NewEdit2.layoutGrid1"
        class={"mx-name-layoutGrid1 mx-layoutgrid mx-layoutgrid-fluid container-fluid"}
        style={undefined}
        content={[
            <$Div key="p26.MyFirstModule.Alergia_NewEdit2.layoutGrid1$row0"
                $widgetId="p26.MyFirstModule.Alergia_NewEdit2.layoutGrid1$row0"
                class={"row"}
                style={undefined}
                content={[
                    <$Div key="p26.MyFirstModule.Alergia_NewEdit2.layoutGrid1$row0$column0"
                        $widgetId="p26.MyFirstModule.Alergia_NewEdit2.layoutGrid1$row0$column0"
                        class={"col-lg col-md col"}
                        style={undefined}
                        content={[
                            <$DataView key="p26.MyFirstModule.Alergia_NewEdit2.dataView6"
                                $widgetId="p26.MyFirstModule.Alergia_NewEdit2.dataView6"
                                class={"mx-name-dataView6 form-vertical"}
                                style={undefined}
                                tabIndex={undefined}
                                object={AssociationObjectProperty({
                                    "dataSourceId": "p26.12",
                                    "scope": "$Alergias",
                                    "editable": true
                                })}
                                emptyMessage={TextProperty({
                                    "value": t([
                                        ""
                                    ])
                                })}
                                body={[
                                    <$FormGroup key="p26.MyFirstModule.Alergia_NewEdit2.textBox1$formGroup"
                                        $widgetId="p26.MyFirstModule.Alergia_NewEdit2.textBox1$formGroup"
                                        class={"mx-name-textBox1 mx-textbox"}
                                        style={undefined}
                                        control={[
                                            <$TextBox key="p26.MyFirstModule.Alergia_NewEdit2.textBox1"
                                                $widgetId="p26.MyFirstModule.Alergia_NewEdit2.textBox1"
                                                inputValue={AttributeProperty({
                                                    "scope": "p26.MyFirstModule.Alergia_NewEdit2.dataView6",
                                                    "path": "",
                                                    "entity": "MyFirstModule.Alergias",
                                                    "attribute": "Titulo",
                                                    "onChange": { "type": "doNothing", "argMap": {}, "config": {}, "disabledDuringExecution": false },
                                                    "isList": false,
                                                    "validation": null,
                                                    "formatting": { }
                                                })}
                                                isPassword={false}
                                                placeholder={t([
                                                    ExpressionProperty({
                                                        "expression": { "expr": { "type": "literal", "value": "" }, "args": {} }
                                                    })
                                                ])}
                                                mask={""}
                                                readOnlyStyle={"control"}
                                                maxLength={200}
                                                onEnter={undefined}
                                                onLeave={undefined}
                                                onEnterKeyPress={undefined}
                                                ariaLabel={undefined}
                                                autocomplete={"on"}
                                                submitWhileEditing={false}
                                                submitDelay={300}
                                                ariaRequired={undefined}
                                                tabIndex={undefined}
                                                id={DerivedUniqueIdProperty({
                                                    "widgetId": "p26.MyFirstModule.Alergia_NewEdit2.textBox1"
                                                })} />
                                        ]}
                                        caption={t([
                                            ExpressionProperty({
                                                "expression": { "expr": { "type": "literal", "value": "Titulo" }, "args": {} }
                                            })
                                        ])}
                                        labelFor={DerivedUniqueIdProperty({
                                            "widgetId": "p26.MyFirstModule.Alergia_NewEdit2.textBox1"
                                        })}
                                        width={undefined}
                                        orientation={"vertical"}
                                        hasError={ValidationProperty({
                                            "inputWidgetId": "p26.MyFirstModule.Alergia_NewEdit2.textBox1"
                                        })} />,
                                    <$FormGroup key="p26.MyFirstModule.Alergia_NewEdit2.textBox2$formGroup"
                                        $widgetId="p26.MyFirstModule.Alergia_NewEdit2.textBox2$formGroup"
                                        class={"mx-name-textBox2 mx-textbox"}
                                        style={undefined}
                                        control={[
                                            <$TextBox key="p26.MyFirstModule.Alergia_NewEdit2.textBox2"
                                                $widgetId="p26.MyFirstModule.Alergia_NewEdit2.textBox2"
                                                inputValue={AttributeProperty({
                                                    "scope": "p26.MyFirstModule.Alergia_NewEdit2.dataView6",
                                                    "path": "",
                                                    "entity": "MyFirstModule.Alergias",
                                                    "attribute": "Tipo",
                                                    "onChange": { "type": "doNothing", "argMap": {}, "config": {}, "disabledDuringExecution": false },
                                                    "isList": false,
                                                    "validation": null,
                                                    "formatting": { }
                                                })}
                                                isPassword={false}
                                                placeholder={t([
                                                    ExpressionProperty({
                                                        "expression": { "expr": { "type": "literal", "value": "" }, "args": {} }
                                                    })
                                                ])}
                                                mask={""}
                                                readOnlyStyle={"control"}
                                                maxLength={200}
                                                onEnter={undefined}
                                                onLeave={undefined}
                                                onEnterKeyPress={undefined}
                                                ariaLabel={undefined}
                                                autocomplete={"on"}
                                                submitWhileEditing={false}
                                                submitDelay={300}
                                                ariaRequired={undefined}
                                                tabIndex={undefined}
                                                id={DerivedUniqueIdProperty({
                                                    "widgetId": "p26.MyFirstModule.Alergia_NewEdit2.textBox2"
                                                })} />
                                        ]}
                                        caption={t([
                                            ExpressionProperty({
                                                "expression": { "expr": { "type": "literal", "value": "Tipo" }, "args": {} }
                                            })
                                        ])}
                                        labelFor={DerivedUniqueIdProperty({
                                            "widgetId": "p26.MyFirstModule.Alergia_NewEdit2.textBox2"
                                        })}
                                        width={undefined}
                                        orientation={"vertical"}
                                        hasError={ValidationProperty({
                                            "inputWidgetId": "p26.MyFirstModule.Alergia_NewEdit2.textBox2"
                                        })} />,
                                    <$FormGroup key="p26.MyFirstModule.Alergia_NewEdit2.textBox3$formGroup"
                                        $widgetId="p26.MyFirstModule.Alergia_NewEdit2.textBox3$formGroup"
                                        class={"mx-name-textBox3 mx-textbox"}
                                        style={undefined}
                                        control={[
                                            <$TextBox key="p26.MyFirstModule.Alergia_NewEdit2.textBox3"
                                                $widgetId="p26.MyFirstModule.Alergia_NewEdit2.textBox3"
                                                inputValue={AttributeProperty({
                                                    "scope": "p26.MyFirstModule.Alergia_NewEdit2.dataView6",
                                                    "path": "",
                                                    "entity": "MyFirstModule.Alergias",
                                                    "attribute": "Reaccion",
                                                    "onChange": { "type": "doNothing", "argMap": {}, "config": {}, "disabledDuringExecution": false },
                                                    "isList": false,
                                                    "validation": null,
                                                    "formatting": { }
                                                })}
                                                isPassword={false}
                                                placeholder={t([
                                                    ExpressionProperty({
                                                        "expression": { "expr": { "type": "literal", "value": "" }, "args": {} }
                                                    })
                                                ])}
                                                mask={""}
                                                readOnlyStyle={"control"}
                                                maxLength={200}
                                                onEnter={undefined}
                                                onLeave={undefined}
                                                onEnterKeyPress={undefined}
                                                ariaLabel={undefined}
                                                autocomplete={"on"}
                                                submitWhileEditing={false}
                                                submitDelay={300}
                                                ariaRequired={undefined}
                                                tabIndex={undefined}
                                                id={DerivedUniqueIdProperty({
                                                    "widgetId": "p26.MyFirstModule.Alergia_NewEdit2.textBox3"
                                                })} />
                                        ]}
                                        caption={t([
                                            ExpressionProperty({
                                                "expression": { "expr": { "type": "literal", "value": "Reaccion" }, "args": {} }
                                            })
                                        ])}
                                        labelFor={DerivedUniqueIdProperty({
                                            "widgetId": "p26.MyFirstModule.Alergia_NewEdit2.textBox3"
                                        })}
                                        width={undefined}
                                        orientation={"vertical"}
                                        hasError={ValidationProperty({
                                            "inputWidgetId": "p26.MyFirstModule.Alergia_NewEdit2.textBox3"
                                        })} />,
                                    <$FormGroup key="p26.MyFirstModule.Alergia_NewEdit2.textBox4$formGroup"
                                        $widgetId="p26.MyFirstModule.Alergia_NewEdit2.textBox4$formGroup"
                                        class={"mx-name-textBox4 mx-textbox"}
                                        style={undefined}
                                        control={[
                                            <$TextBox key="p26.MyFirstModule.Alergia_NewEdit2.textBox4"
                                                $widgetId="p26.MyFirstModule.Alergia_NewEdit2.textBox4"
                                                inputValue={AttributeProperty({
                                                    "scope": "p26.MyFirstModule.Alergia_NewEdit2.dataView6",
                                                    "path": "",
                                                    "entity": "MyFirstModule.Alergias",
                                                    "attribute": "Descripcion",
                                                    "onChange": { "type": "doNothing", "argMap": {}, "config": {}, "disabledDuringExecution": false },
                                                    "isList": false,
                                                    "validation": null,
                                                    "formatting": { }
                                                })}
                                                isPassword={false}
                                                placeholder={t([
                                                    ExpressionProperty({
                                                        "expression": { "expr": { "type": "literal", "value": "" }, "args": {} }
                                                    })
                                                ])}
                                                mask={""}
                                                readOnlyStyle={"control"}
                                                maxLength={200}
                                                onEnter={undefined}
                                                onLeave={undefined}
                                                onEnterKeyPress={undefined}
                                                ariaLabel={undefined}
                                                autocomplete={"on"}
                                                submitWhileEditing={false}
                                                submitDelay={300}
                                                ariaRequired={undefined}
                                                tabIndex={undefined}
                                                id={DerivedUniqueIdProperty({
                                                    "widgetId": "p26.MyFirstModule.Alergia_NewEdit2.textBox4"
                                                })} />
                                        ]}
                                        caption={t([
                                            ExpressionProperty({
                                                "expression": { "expr": { "type": "literal", "value": "Descripcion" }, "args": {} }
                                            })
                                        ])}
                                        labelFor={DerivedUniqueIdProperty({
                                            "widgetId": "p26.MyFirstModule.Alergia_NewEdit2.textBox4"
                                        })}
                                        width={undefined}
                                        orientation={"vertical"}
                                        hasError={ValidationProperty({
                                            "inputWidgetId": "p26.MyFirstModule.Alergia_NewEdit2.textBox4"
                                        })} />
                                ]}
                                hideFooter={false}
                                footer={[
                                    <$ActionButton key="p26.MyFirstModule.Alergia_NewEdit2.actionButton1"
                                        $widgetId="p26.MyFirstModule.Alergia_NewEdit2.actionButton1"
                                        buttonId={"p26.MyFirstModule.Alergia_NewEdit2.actionButton1"}
                                        class={"mx-name-actionButton1"}
                                        style={undefined}
                                        tabIndex={undefined}
                                        renderType={"button"}
                                        role={undefined}
                                        buttonClass={"btn-primary"}
                                        caption={t([
                                            ExpressionProperty({
                                                "expression": { "expr": { "type": "literal", "value": "Save" }, "args": {} }
                                            })
                                        ])}
                                        tooltip={TextProperty({
                                            "value": t([
                                                ""
                                            ])
                                        })}
                                        icon={undefined}
                                        action={ActionProperty({
                                            "action": { "type": "saveChanges", "argMap": { "$object": { "widget": "p26.MyFirstModule.Alergia_NewEdit2.dataView6", "source": "object" } }, "config": { "operationId": "7b15yx8yXFOWkmHnSRhXTw", "closePage": true }, "disabledDuringExecution": true },
                                            "abortOnServerValidation": true
                                        })} />,
                                    <$ActionButton key="p26.MyFirstModule.Alergia_NewEdit2.actionButton2"
                                        $widgetId="p26.MyFirstModule.Alergia_NewEdit2.actionButton2"
                                        buttonId={"p26.MyFirstModule.Alergia_NewEdit2.actionButton2"}
                                        class={"mx-name-actionButton2"}
                                        style={undefined}
                                        tabIndex={undefined}
                                        renderType={"button"}
                                        role={undefined}
                                        buttonClass={"btn-default"}
                                        caption={t([
                                            ExpressionProperty({
                                                "expression": { "expr": { "type": "literal", "value": "Cancel" }, "args": {} }
                                            })
                                        ])}
                                        tooltip={TextProperty({
                                            "value": t([
                                                ""
                                            ])
                                        })}
                                        icon={undefined}
                                        action={ActionProperty({
                                            "action": { "type": "cancelChanges", "argMap": {}, "config": { "operationId": "zF9Fl4WGZF+hazoepjtn/A", "closePage": true }, "disabledDuringExecution": true },
                                            "abortOnServerValidation": true
                                        })} />
                                ]} />
                        ]} />
                ]} />
        ]} />
]}</PageFragment>);

export const title = t([
    "Agregar Alergia"
]);

export const classes = "";

export const cancelChangesOperationId = "ltOZbwWllleAx3bDk/Qx0Q";
export const style = {};
export const content = { ...parentContent,
    "Atlas_Core.PopupLayout.Main": region$Main,
};
