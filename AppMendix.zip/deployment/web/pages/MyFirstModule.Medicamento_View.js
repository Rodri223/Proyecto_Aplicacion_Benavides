import { createElement } from "react";
const React = { createElement };

import { PageFragment } from "mendix/PageFragment";
import { ActionProperty } from "mendix/ActionProperty";
import { AssociationObjectProperty } from "mendix/AssociationObjectProperty";
import { AttributeProperty } from "mendix/AttributeProperty";
import { DerivedUniqueIdProperty } from "mendix/DerivedUniqueIdProperty";
import { ExpressionProperty } from "mendix/ExpressionProperty";
import { TextProperty } from "mendix/TextProperty";
import { ValidationProperty } from "mendix/ValidationProperty";

import { ActionButton } from "mendix/widgets/web/ActionButton";
import { DataView } from "mendix/widgets/web/DataView";
import { Div } from "mendix/widgets/web/Div";
import { FormGroup } from "mendix/widgets/web/FormGroup";
import { TextBox } from "mendix/widgets/web/TextBox";
import { addEnumerations, asPluginWidgets, t } from "mendix";

import { content as parentContent } from "../layouts/Atlas_Core.PopupLayout.js";

const { $Div, $DataView, $FormGroup, $TextBox, $ActionButton } = asPluginWidgets({ Div, DataView, FormGroup, TextBox, ActionButton });

const region$Main = (historyId) => (<PageFragment renderKey={historyId}>{[
    <$Div key="p36.MyFirstModule.Medicamento_View.layoutGrid1"
        $widgetId="p36.MyFirstModule.Medicamento_View.layoutGrid1"
        class={"mx-name-layoutGrid1 mx-layoutgrid mx-layoutgrid-fluid container-fluid"}
        style={undefined}
        content={[
            <$Div key="p36.MyFirstModule.Medicamento_View.layoutGrid1$row0"
                $widgetId="p36.MyFirstModule.Medicamento_View.layoutGrid1$row0"
                class={"row"}
                style={undefined}
                content={[
                    <$Div key="p36.MyFirstModule.Medicamento_View.layoutGrid1$row0$column0"
                        $widgetId="p36.MyFirstModule.Medicamento_View.layoutGrid1$row0$column0"
                        class={"col-lg col-md col"}
                        style={undefined}
                        content={[
                            <$DataView key="p36.MyFirstModule.Medicamento_View.dataView6"
                                $widgetId="p36.MyFirstModule.Medicamento_View.dataView6"
                                class={"mx-name-dataView6 form-vertical"}
                                style={undefined}
                                tabIndex={undefined}
                                object={AssociationObjectProperty({
                                    "dataSourceId": "p36.12",
                                    "scope": "$Medicamento",
                                    "editable": true
                                })}
                                emptyMessage={TextProperty({
                                    "value": t([
                                        ""
                                    ])
                                })}
                                body={[
                                    <$FormGroup key="p36.MyFirstModule.Medicamento_View.textBox1$formGroup"
                                        $widgetId="p36.MyFirstModule.Medicamento_View.textBox1$formGroup"
                                        class={"mx-name-textBox1 mx-textbox"}
                                        style={undefined}
                                        control={[
                                            <$TextBox key="p36.MyFirstModule.Medicamento_View.textBox1"
                                                $widgetId="p36.MyFirstModule.Medicamento_View.textBox1"
                                                inputValue={AttributeProperty({
                                                    "scope": "p36.MyFirstModule.Medicamento_View.dataView6",
                                                    "path": "",
                                                    "entity": "MyFirstModule.Medicamento",
                                                    "attribute": "Titulo",
                                                    "onChange": { "type": "doNothing", "argMap": {}, "config": {}, "disabledDuringExecution": false },
                                                    "isList": false,
                                                    "validation": null,
                                                    "formatting": { }
                                                })}
                                                isPassword={false}
                                                placeholder={t([
                                                    ExpressionProperty({
                                                        "expression": { "expr": { "type": "literal", "value": "" }, "args": {} }
                                                    })
                                                ])}
                                                mask={""}
                                                readOnlyStyle={"control"}
                                                maxLength={200}
                                                onEnter={undefined}
                                                onLeave={undefined}
                                                onEnterKeyPress={undefined}
                                                ariaLabel={undefined}
                                                autocomplete={"on"}
                                                submitWhileEditing={false}
                                                submitDelay={300}
                                                ariaRequired={undefined}
                                                tabIndex={undefined}
                                                id={DerivedUniqueIdProperty({
                                                    "widgetId": "p36.MyFirstModule.Medicamento_View.textBox1"
                                                })} />
                                        ]}
                                        caption={t([
                                            ExpressionProperty({
                                                "expression": { "expr": { "type": "literal", "value": "Titulo" }, "args": {} }
                                            })
                                        ])}
                                        labelFor={DerivedUniqueIdProperty({
                                            "widgetId": "p36.MyFirstModule.Medicamento_View.textBox1"
                                        })}
                                        width={undefined}
                                        orientation={"vertical"}
                                        hasError={ValidationProperty({
                                            "inputWidgetId": "p36.MyFirstModule.Medicamento_View.textBox1"
                                        })} />,
                                    <$FormGroup key="p36.MyFirstModule.Medicamento_View.textBox2$formGroup"
                                        $widgetId="p36.MyFirstModule.Medicamento_View.textBox2$formGroup"
                                        class={"mx-name-textBox2 mx-textbox"}
                                        style={undefined}
                                        control={[
                                            <$TextBox key="p36.MyFirstModule.Medicamento_View.textBox2"
                                                $widgetId="p36.MyFirstModule.Medicamento_View.textBox2"
                                                inputValue={AttributeProperty({
                                                    "scope": "p36.MyFirstModule.Medicamento_View.dataView6",
                                                    "path": "",
                                                    "entity": "MyFirstModule.Medicamento",
                                                    "attribute": "Dosis",
                                                    "onChange": { "type": "doNothing", "argMap": {}, "config": {}, "disabledDuringExecution": false },
                                                    "isList": false,
                                                    "validation": null,
                                                    "formatting": { }
                                                })}
                                                isPassword={false}
                                                placeholder={t([
                                                    ExpressionProperty({
                                                        "expression": { "expr": { "type": "literal", "value": "" }, "args": {} }
                                                    })
                                                ])}
                                                mask={""}
                                                readOnlyStyle={"control"}
                                                maxLength={200}
                                                onEnter={undefined}
                                                onLeave={undefined}
                                                onEnterKeyPress={undefined}
                                                ariaLabel={undefined}
                                                autocomplete={"on"}
                                                submitWhileEditing={false}
                                                submitDelay={300}
                                                ariaRequired={undefined}
                                                tabIndex={undefined}
                                                id={DerivedUniqueIdProperty({
                                                    "widgetId": "p36.MyFirstModule.Medicamento_View.textBox2"
                                                })} />
                                        ]}
                                        caption={t([
                                            ExpressionProperty({
                                                "expression": { "expr": { "type": "literal", "value": "Dosis" }, "args": {} }
                                            })
                                        ])}
                                        labelFor={DerivedUniqueIdProperty({
                                            "widgetId": "p36.MyFirstModule.Medicamento_View.textBox2"
                                        })}
                                        width={undefined}
                                        orientation={"vertical"}
                                        hasError={ValidationProperty({
                                            "inputWidgetId": "p36.MyFirstModule.Medicamento_View.textBox2"
                                        })} />,
                                    <$FormGroup key="p36.MyFirstModule.Medicamento_View.textBox3$formGroup"
                                        $widgetId="p36.MyFirstModule.Medicamento_View.textBox3$formGroup"
                                        class={"mx-name-textBox3 mx-textbox"}
                                        style={undefined}
                                        control={[
                                            <$TextBox key="p36.MyFirstModule.Medicamento_View.textBox3"
                                                $widgetId="p36.MyFirstModule.Medicamento_View.textBox3"
                                                inputValue={AttributeProperty({
                                                    "scope": "p36.MyFirstModule.Medicamento_View.dataView6",
                                                    "path": "",
                                                    "entity": "MyFirstModule.Medicamento",
                                                    "attribute": "Frecuencia",
                                                    "onChange": { "type": "doNothing", "argMap": {}, "config": {}, "disabledDuringExecution": false },
                                                    "isList": false,
                                                    "validation": null,
                                                    "formatting": { }
                                                })}
                                                isPassword={false}
                                                placeholder={t([
                                                    ExpressionProperty({
                                                        "expression": { "expr": { "type": "literal", "value": "" }, "args": {} }
                                                    })
                                                ])}
                                                mask={""}
                                                readOnlyStyle={"control"}
                                                maxLength={200}
                                                onEnter={undefined}
                                                onLeave={undefined}
                                                onEnterKeyPress={undefined}
                                                ariaLabel={undefined}
                                                autocomplete={"on"}
                                                submitWhileEditing={false}
                                                submitDelay={300}
                                                ariaRequired={undefined}
                                                tabIndex={undefined}
                                                id={DerivedUniqueIdProperty({
                                                    "widgetId": "p36.MyFirstModule.Medicamento_View.textBox3"
                                                })} />
                                        ]}
                                        caption={t([
                                            ExpressionProperty({
                                                "expression": { "expr": { "type": "literal", "value": "Frecuencia" }, "args": {} }
                                            })
                                        ])}
                                        labelFor={DerivedUniqueIdProperty({
                                            "widgetId": "p36.MyFirstModule.Medicamento_View.textBox3"
                                        })}
                                        width={undefined}
                                        orientation={"vertical"}
                                        hasError={ValidationProperty({
                                            "inputWidgetId": "p36.MyFirstModule.Medicamento_View.textBox3"
                                        })} />,
                                    <$FormGroup key="p36.MyFirstModule.Medicamento_View.textBox4$formGroup"
                                        $widgetId="p36.MyFirstModule.Medicamento_View.textBox4$formGroup"
                                        class={"mx-name-textBox4 mx-textbox"}
                                        style={undefined}
                                        control={[
                                            <$TextBox key="p36.MyFirstModule.Medicamento_View.textBox4"
                                                $widgetId="p36.MyFirstModule.Medicamento_View.textBox4"
                                                inputValue={AttributeProperty({
                                                    "scope": "p36.MyFirstModule.Medicamento_View.dataView6",
                                                    "path": "",
                                                    "entity": "MyFirstModule.Medicamento",
                                                    "attribute": "Duracion",
                                                    "onChange": { "type": "doNothing", "argMap": {}, "config": {}, "disabledDuringExecution": false },
                                                    "isList": false,
                                                    "validation": null,
                                                    "formatting": { }
                                                })}
                                                isPassword={false}
                                                placeholder={t([
                                                    ExpressionProperty({
                                                        "expression": { "expr": { "type": "literal", "value": "" }, "args": {} }
                                                    })
                                                ])}
                                                mask={""}
                                                readOnlyStyle={"control"}
                                                maxLength={200}
                                                onEnter={undefined}
                                                onLeave={undefined}
                                                onEnterKeyPress={undefined}
                                                ariaLabel={undefined}
                                                autocomplete={"on"}
                                                submitWhileEditing={false}
                                                submitDelay={300}
                                                ariaRequired={undefined}
                                                tabIndex={undefined}
                                                id={DerivedUniqueIdProperty({
                                                    "widgetId": "p36.MyFirstModule.Medicamento_View.textBox4"
                                                })} />
                                        ]}
                                        caption={t([
                                            ExpressionProperty({
                                                "expression": { "expr": { "type": "literal", "value": "Duracion" }, "args": {} }
                                            })
                                        ])}
                                        labelFor={DerivedUniqueIdProperty({
                                            "widgetId": "p36.MyFirstModule.Medicamento_View.textBox4"
                                        })}
                                        width={undefined}
                                        orientation={"vertical"}
                                        hasError={ValidationProperty({
                                            "inputWidgetId": "p36.MyFirstModule.Medicamento_View.textBox4"
                                        })} />,
                                    <$FormGroup key="p36.MyFirstModule.Medicamento_View.textBox5$formGroup"
                                        $widgetId="p36.MyFirstModule.Medicamento_View.textBox5$formGroup"
                                        class={"mx-name-textBox5 mx-textbox"}
                                        style={undefined}
                                        control={[
                                            <$TextBox key="p36.MyFirstModule.Medicamento_View.textBox5"
                                                $widgetId="p36.MyFirstModule.Medicamento_View.textBox5"
                                                inputValue={AttributeProperty({
                                                    "scope": "p36.MyFirstModule.Medicamento_View.dataView6",
                                                    "path": "",
                                                    "entity": "MyFirstModule.Medicamento",
                                                    "attribute": "Instrucciones",
                                                    "onChange": { "type": "doNothing", "argMap": {}, "config": {}, "disabledDuringExecution": false },
                                                    "isList": false,
                                                    "validation": null,
                                                    "formatting": { }
                                                })}
                                                isPassword={false}
                                                placeholder={t([
                                                    ExpressionProperty({
                                                        "expression": { "expr": { "type": "literal", "value": "" }, "args": {} }
                                                    })
                                                ])}
                                                mask={""}
                                                readOnlyStyle={"control"}
                                                maxLength={200}
                                                onEnter={undefined}
                                                onLeave={undefined}
                                                onEnterKeyPress={undefined}
                                                ariaLabel={undefined}
                                                autocomplete={"on"}
                                                submitWhileEditing={false}
                                                submitDelay={300}
                                                ariaRequired={undefined}
                                                tabIndex={undefined}
                                                id={DerivedUniqueIdProperty({
                                                    "widgetId": "p36.MyFirstModule.Medicamento_View.textBox5"
                                                })} />
                                        ]}
                                        caption={t([
                                            ExpressionProperty({
                                                "expression": { "expr": { "type": "literal", "value": "Instrucciones" }, "args": {} }
                                            })
                                        ])}
                                        labelFor={DerivedUniqueIdProperty({
                                            "widgetId": "p36.MyFirstModule.Medicamento_View.textBox5"
                                        })}
                                        width={undefined}
                                        orientation={"vertical"}
                                        hasError={ValidationProperty({
                                            "inputWidgetId": "p36.MyFirstModule.Medicamento_View.textBox5"
                                        })} />
                                ]}
                                hideFooter={false}
                                footer={[
                                    <$ActionButton key="p36.MyFirstModule.Medicamento_View.actionButton1"
                                        $widgetId="p36.MyFirstModule.Medicamento_View.actionButton1"
                                        buttonId={"p36.MyFirstModule.Medicamento_View.actionButton1"}
                                        class={"mx-name-actionButton1"}
                                        style={undefined}
                                        tabIndex={undefined}
                                        renderType={"button"}
                                        role={undefined}
                                        buttonClass={"btn-primary"}
                                        caption={t([
                                            ExpressionProperty({
                                                "expression": { "expr": { "type": "literal", "value": "Save" }, "args": {} }
                                            })
                                        ])}
                                        tooltip={TextProperty({
                                            "value": t([
                                                ""
                                            ])
                                        })}
                                        icon={undefined}
                                        action={ActionProperty({
                                            "action": { "type": "saveChanges", "argMap": { "$object": { "widget": "p36.MyFirstModule.Medicamento_View.dataView6", "source": "object" } }, "config": { "operationId": "9ikhLJqUZlWD/GafuBokrA", "closePage": true }, "disabledDuringExecution": true },
                                            "abortOnServerValidation": true
                                        })} />,
                                    <$ActionButton key="p36.MyFirstModule.Medicamento_View.actionButton3"
                                        $widgetId="p36.MyFirstModule.Medicamento_View.actionButton3"
                                        buttonId={"p36.MyFirstModule.Medicamento_View.actionButton3"}
                                        class={"mx-name-actionButton3"}
                                        style={undefined}
                                        tabIndex={undefined}
                                        renderType={"button"}
                                        role={undefined}
                                        buttonClass={"btn-default"}
                                        caption={t([
                                            ExpressionProperty({
                                                "expression": { "expr": { "type": "literal", "value": "Delete" }, "args": {} }
                                            })
                                        ])}
                                        tooltip={TextProperty({
                                            "value": t([
                                                ""
                                            ])
                                        })}
                                        icon={undefined}
                                        action={ActionProperty({
                                            "action": { "type": "deleteObject", "argMap": { "$object": { "widget": "$Medicamento", "source": "object" } }, "config": { "closePage": true, "operationId": "lXt4ZoXvf1C/GvG0gWMZ5g" }, "disabledDuringExecution": true },
                                            "abortOnServerValidation": true
                                        })} />
                                ]} />
                        ]} />
                ]} />
        ]} />
]}</PageFragment>);

export const title = t([
    "Medicamento View"
]);

export const classes = "";

export const cancelChangesOperationId = "NJv5AnOlg1mI50dJRcK1cQ";
export const style = {};
export const content = { ...parentContent,
    "Atlas_Core.PopupLayout.Main": region$Main,
};
