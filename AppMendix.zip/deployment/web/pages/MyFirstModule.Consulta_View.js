import { createElement } from "react";
const React = { createElement };

import { PageFragment } from "mendix/PageFragment";
import { ActionProperty } from "mendix/ActionProperty";
import { AssociationObjectProperty } from "mendix/AssociationObjectProperty";
import { AttributeProperty } from "mendix/AttributeProperty";
import { DatabaseObjectListProperty } from "mendix/DatabaseObjectListProperty";
import { DerivedUniqueIdProperty } from "mendix/DerivedUniqueIdProperty";
import { ExpressionProperty } from "mendix/ExpressionProperty";
import { TemplatedWidgetProperty } from "mendix/TemplatedWidgetProperty";
import { TextProperty } from "mendix/TextProperty";
import { ValidationProperty } from "mendix/ValidationProperty";
import { WebIconProperty } from "mendix/WebIconProperty";

import { ActionButton } from "mendix/widgets/web/ActionButton";
import { DataView } from "mendix/widgets/web/DataView";
import { DatePicker } from "mendix/widgets/web/DatePicker";
import { Div } from "mendix/widgets/web/Div";
import { FormGroup } from "mendix/widgets/web/FormGroup";
import { GroupBox } from "mendix/widgets/web/GroupBox";
import { ListView } from "mendix/widgets/web/ListView";
import { Text } from "mendix/widgets/web/Text";
import { TextBox } from "mendix/widgets/web/TextBox";
import { addEnumerations, asPluginWidgets, t } from "mendix";

import { content as parentContent } from "../layouts/Atlas_Core.PopupLayout.js";

const { $Div, $DataView, $FormGroup, $TextBox, $DatePicker, $ActionButton, $ListView, $GroupBox, $Text } = asPluginWidgets({ Div, DataView, FormGroup, TextBox, DatePicker, ActionButton, ListView, GroupBox, Text });

const region$Main = (historyId) => (<PageFragment renderKey={historyId}>{[
    <$Div key="p33.MyFirstModule.Consulta_View.layoutGrid1"
        $widgetId="p33.MyFirstModule.Consulta_View.layoutGrid1"
        class={"mx-name-layoutGrid1 mx-layoutgrid mx-layoutgrid-fluid container-fluid"}
        style={undefined}
        content={[
            <$Div key="p33.MyFirstModule.Consulta_View.layoutGrid1$row0"
                $widgetId="p33.MyFirstModule.Consulta_View.layoutGrid1$row0"
                class={"row"}
                style={undefined}
                content={[
                    <$Div key="p33.MyFirstModule.Consulta_View.layoutGrid1$row0$column0"
                        $widgetId="p33.MyFirstModule.Consulta_View.layoutGrid1$row0$column0"
                        class={"col-lg col-md col"}
                        style={undefined}
                        content={[
                            <$DataView key="p33.MyFirstModule.Consulta_View.dataView6"
                                $widgetId="p33.MyFirstModule.Consulta_View.dataView6"
                                class={"mx-name-dataView6 form-vertical"}
                                style={undefined}
                                tabIndex={undefined}
                                object={AssociationObjectProperty({
                                    "dataSourceId": "p33.17",
                                    "scope": "$Consulta",
                                    "editable": true
                                })}
                                emptyMessage={TextProperty({
                                    "value": t([
                                        ""
                                    ])
                                })}
                                body={[
                                    <$FormGroup key="p33.MyFirstModule.Consulta_View.textBox1$formGroup"
                                        $widgetId="p33.MyFirstModule.Consulta_View.textBox1$formGroup"
                                        class={"mx-name-textBox1 mx-textbox"}
                                        style={undefined}
                                        control={[
                                            <$TextBox key="p33.MyFirstModule.Consulta_View.textBox1"
                                                $widgetId="p33.MyFirstModule.Consulta_View.textBox1"
                                                inputValue={AttributeProperty({
                                                    "scope": "p33.MyFirstModule.Consulta_View.dataView6",
                                                    "path": "",
                                                    "entity": "MyFirstModule.Consulta",
                                                    "attribute": "Paciente",
                                                    "onChange": { "type": "doNothing", "argMap": {}, "config": {}, "disabledDuringExecution": false },
                                                    "isList": false,
                                                    "validation": null,
                                                    "formatting": { }
                                                })}
                                                isPassword={false}
                                                placeholder={t([
                                                    ExpressionProperty({
                                                        "expression": { "expr": { "type": "literal", "value": "" }, "args": {} }
                                                    })
                                                ])}
                                                mask={""}
                                                readOnlyStyle={"control"}
                                                maxLength={200}
                                                onEnter={undefined}
                                                onLeave={undefined}
                                                onEnterKeyPress={undefined}
                                                ariaLabel={undefined}
                                                autocomplete={"on"}
                                                submitWhileEditing={false}
                                                submitDelay={300}
                                                ariaRequired={undefined}
                                                tabIndex={undefined}
                                                id={DerivedUniqueIdProperty({
                                                    "widgetId": "p33.MyFirstModule.Consulta_View.textBox1"
                                                })} />
                                        ]}
                                        caption={t([
                                            ExpressionProperty({
                                                "expression": { "expr": { "type": "literal", "value": "Paciente" }, "args": {} }
                                            })
                                        ])}
                                        labelFor={DerivedUniqueIdProperty({
                                            "widgetId": "p33.MyFirstModule.Consulta_View.textBox1"
                                        })}
                                        width={undefined}
                                        orientation={"vertical"}
                                        hasError={ValidationProperty({
                                            "inputWidgetId": "p33.MyFirstModule.Consulta_View.textBox1"
                                        })} />,
                                    <$FormGroup key="p33.MyFirstModule.Consulta_View.textBox2$formGroup"
                                        $widgetId="p33.MyFirstModule.Consulta_View.textBox2$formGroup"
                                        class={"mx-name-textBox2 mx-textbox"}
                                        style={undefined}
                                        control={[
                                            <$TextBox key="p33.MyFirstModule.Consulta_View.textBox2"
                                                $widgetId="p33.MyFirstModule.Consulta_View.textBox2"
                                                inputValue={AttributeProperty({
                                                    "scope": "p33.MyFirstModule.Consulta_View.dataView6",
                                                    "path": "",
                                                    "entity": "MyFirstModule.Consulta",
                                                    "attribute": "Medico",
                                                    "onChange": { "type": "doNothing", "argMap": {}, "config": {}, "disabledDuringExecution": false },
                                                    "isList": false,
                                                    "validation": null,
                                                    "formatting": { }
                                                })}
                                                isPassword={false}
                                                placeholder={t([
                                                    ExpressionProperty({
                                                        "expression": { "expr": { "type": "literal", "value": "" }, "args": {} }
                                                    })
                                                ])}
                                                mask={""}
                                                readOnlyStyle={"control"}
                                                maxLength={200}
                                                onEnter={undefined}
                                                onLeave={undefined}
                                                onEnterKeyPress={undefined}
                                                ariaLabel={undefined}
                                                autocomplete={"on"}
                                                submitWhileEditing={false}
                                                submitDelay={300}
                                                ariaRequired={undefined}
                                                tabIndex={undefined}
                                                id={DerivedUniqueIdProperty({
                                                    "widgetId": "p33.MyFirstModule.Consulta_View.textBox2"
                                                })} />
                                        ]}
                                        caption={t([
                                            ExpressionProperty({
                                                "expression": { "expr": { "type": "literal", "value": "Medico" }, "args": {} }
                                            })
                                        ])}
                                        labelFor={DerivedUniqueIdProperty({
                                            "widgetId": "p33.MyFirstModule.Consulta_View.textBox2"
                                        })}
                                        width={undefined}
                                        orientation={"vertical"}
                                        hasError={ValidationProperty({
                                            "inputWidgetId": "p33.MyFirstModule.Consulta_View.textBox2"
                                        })} />,
                                    <$FormGroup key="p33.MyFirstModule.Consulta_View.textBox3$formGroup"
                                        $widgetId="p33.MyFirstModule.Consulta_View.textBox3$formGroup"
                                        class={"mx-name-textBox3 mx-textbox"}
                                        style={undefined}
                                        control={[
                                            <$TextBox key="p33.MyFirstModule.Consulta_View.textBox3"
                                                $widgetId="p33.MyFirstModule.Consulta_View.textBox3"
                                                inputValue={AttributeProperty({
                                                    "scope": "p33.MyFirstModule.Consulta_View.dataView6",
                                                    "path": "",
                                                    "entity": "MyFirstModule.Consulta",
                                                    "attribute": "Motivo",
                                                    "onChange": { "type": "doNothing", "argMap": {}, "config": {}, "disabledDuringExecution": false },
                                                    "isList": false,
                                                    "validation": null,
                                                    "formatting": { }
                                                })}
                                                isPassword={false}
                                                placeholder={t([
                                                    ExpressionProperty({
                                                        "expression": { "expr": { "type": "literal", "value": "" }, "args": {} }
                                                    })
                                                ])}
                                                mask={""}
                                                readOnlyStyle={"control"}
                                                maxLength={200}
                                                onEnter={undefined}
                                                onLeave={undefined}
                                                onEnterKeyPress={undefined}
                                                ariaLabel={undefined}
                                                autocomplete={"on"}
                                                submitWhileEditing={false}
                                                submitDelay={300}
                                                ariaRequired={undefined}
                                                tabIndex={undefined}
                                                id={DerivedUniqueIdProperty({
                                                    "widgetId": "p33.MyFirstModule.Consulta_View.textBox3"
                                                })} />
                                        ]}
                                        caption={t([
                                            ExpressionProperty({
                                                "expression": { "expr": { "type": "literal", "value": "Motivo" }, "args": {} }
                                            })
                                        ])}
                                        labelFor={DerivedUniqueIdProperty({
                                            "widgetId": "p33.MyFirstModule.Consulta_View.textBox3"
                                        })}
                                        width={undefined}
                                        orientation={"vertical"}
                                        hasError={ValidationProperty({
                                            "inputWidgetId": "p33.MyFirstModule.Consulta_View.textBox3"
                                        })} />,
                                    <$FormGroup key="p33.MyFirstModule.Consulta_View.datePicker1$formGroup"
                                        $widgetId="p33.MyFirstModule.Consulta_View.datePicker1$formGroup"
                                        class={"mx-name-datePicker1 mx-datepicker"}
                                        style={undefined}
                                        control={[
                                            <$DatePicker key="p33.MyFirstModule.Consulta_View.datePicker1"
                                                $widgetId="p33.MyFirstModule.Consulta_View.datePicker1"
                                                mode={"date"}
                                                showCalendarButton={true}
                                                inputValue={AttributeProperty({
                                                    "scope": "p33.MyFirstModule.Consulta_View.dataView6",
                                                    "path": "",
                                                    "entity": "MyFirstModule.Consulta",
                                                    "attribute": "FechaConsulta",
                                                    "onChange": { "type": "doNothing", "argMap": {}, "config": {}, "disabledDuringExecution": false },
                                                    "isList": false,
                                                    "validation": null,
                                                    "formatting": {
                                                        "dateFormat": t([
                                                            {
                                                                "type": "date"
                                                            }
                                                        ])
                                                    }
                                                })}
                                                placeholder={t([
                                                    ExpressionProperty({
                                                        "expression": { "expr": { "type": "literal", "value": "" }, "args": {} }
                                                    })
                                                ])}
                                                buttonLabel={TextProperty({
                                                    "value": t([
                                                        "Show date picker"
                                                    ])
                                                })}
                                                readOnlyStyle={"control"}
                                                onEnter={undefined}
                                                onLeave={undefined}
                                                ariaLabel={undefined}
                                                ariaRequired={undefined}
                                                tabIndex={undefined}
                                                id={DerivedUniqueIdProperty({
                                                    "widgetId": "p33.MyFirstModule.Consulta_View.datePicker1"
                                                })} />
                                        ]}
                                        caption={t([
                                            ExpressionProperty({
                                                "expression": { "expr": { "type": "literal", "value": "Fecha consulta" }, "args": {} }
                                            })
                                        ])}
                                        labelFor={DerivedUniqueIdProperty({
                                            "widgetId": "p33.MyFirstModule.Consulta_View.datePicker1"
                                        })}
                                        width={undefined}
                                        orientation={"vertical"}
                                        hasError={ValidationProperty({
                                            "inputWidgetId": "p33.MyFirstModule.Consulta_View.datePicker1"
                                        })} />,
                                    <$Div key="p33.MyFirstModule.Consulta_View.layoutGrid3"
                                        $widgetId="p33.MyFirstModule.Consulta_View.layoutGrid3"
                                        class={"mx-name-layoutGrid3 mx-layoutgrid mx-layoutgrid-fluid"}
                                        style={undefined}
                                        content={[
                                            <$Div key="p33.MyFirstModule.Consulta_View.layoutGrid3$row0"
                                                $widgetId="p33.MyFirstModule.Consulta_View.layoutGrid3$row0"
                                                class={"row"}
                                                style={undefined}
                                                content={[
                                                    <$Div key="p33.MyFirstModule.Consulta_View.layoutGrid3$row0$column0"
                                                        $widgetId="p33.MyFirstModule.Consulta_View.layoutGrid3$row0$column0"
                                                        class={"col-lg col-md col align-self-center"}
                                                        style={undefined}
                                                        content={[
                                                            <$ActionButton key="p33.MyFirstModule.Consulta_View.actionButton3"
                                                                $widgetId="p33.MyFirstModule.Consulta_View.actionButton3"
                                                                buttonId={"p33.MyFirstModule.Consulta_View.actionButton3"}
                                                                class={"mx-name-actionButton3 btn-icon-right pull-left spacing-outer-bottom"}
                                                                style={undefined}
                                                                tabIndex={undefined}
                                                                renderType={"button"}
                                                                role={undefined}
                                                                buttonClass={"btn-default"}
                                                                caption={t([
                                                                    ExpressionProperty({
                                                                        "expression": { "expr": { "type": "literal", "value": "Crear Receta" }, "args": {} }
                                                                    })
                                                                ])}
                                                                tooltip={TextProperty({
                                                                    "value": t([
                                                                        ""
                                                                    ])
                                                                })}
                                                                icon={WebIconProperty({
                                                                    "icon": { "type": "icon", "iconClass": "mx-icon-lined mx-icon-add" }
                                                                })}
                                                                action={ActionProperty({
                                                                    "action": { "type": "callMicroflow", "argMap": { "Consulta": { "widget": "$Consulta", "source": "object" } }, "config": { "operationId": "2rlbZMYS+lmjl8PFzwRg4g", "validate": "view" }, "disabledDuringExecution": true },
                                                                    "abortOnServerValidation": true
                                                                })} />
                                                        ]} />
                                                ]} />
                                        ]} />,
                                    <$Div key="p33.MyFirstModule.Consulta_View.layoutGrid2"
                                        $widgetId="p33.MyFirstModule.Consulta_View.layoutGrid2"
                                        class={"mx-name-layoutGrid2 mx-layoutgrid mx-layoutgrid-fluid"}
                                        style={undefined}
                                        content={[
                                            <$Div key="p33.MyFirstModule.Consulta_View.layoutGrid2$row0"
                                                $widgetId="p33.MyFirstModule.Consulta_View.layoutGrid2$row0"
                                                class={"row"}
                                                style={undefined}
                                                content={[
                                                    <$Div key="p33.MyFirstModule.Consulta_View.layoutGrid2$row0$column0"
                                                        $widgetId="p33.MyFirstModule.Consulta_View.layoutGrid2$row0$column0"
                                                        class={"col-lg col-md col"}
                                                        style={undefined}
                                                        content={undefined} />
                                                ]} />
                                        ]} />,
                                    <$ListView key="p33.MyFirstModule.Consulta_View.listView1"
                                        $widgetId="p33.MyFirstModule.Consulta_View.listView1"
                                        class={"mx-name-listView1"}
                                        style={undefined}
                                        listValue={DatabaseObjectListProperty({
                                            "dataSourceId": "p33.2",
                                            "entity": "MyFirstModule.Receta",
                                            "scope": "p33.MyFirstModule.Consulta_View.dataView6",
                                            "operationId": "/V+nRO6ySlqhI+5ALja0cQ",
                                            "sort": [],
                                            "arguments": {
                                                "currentObject": [
                                                    "$Consulta"
                                                ],
                                                "CurrentObject": [
                                                    "$Consulta"
                                                ]
                                            },
                                            "constraints": { "type": "function", "name": "=", "parameters": [ { "type": "attribute", "attribute": "MyFirstModule.Receta_Consulta", "context": "MyFirstModule.Receta", "attributeType": "ObjectReference" }, { "type": "variable", "name": "currentObject" } ] }
                                        })}
                                        itemTemplate={TemplatedWidgetProperty({
                                            "dataSourceId": "p33.2",
                                            "editable": false,
                                            "children": () => [
                                                <$GroupBox key="p33.MyFirstModule.Consulta_View.groupBox1"
                                                    $widgetId="p33.MyFirstModule.Consulta_View.groupBox1"
                                                    id={DerivedUniqueIdProperty({
                                                        "widgetId": "p33.MyFirstModule.Consulta_View.groupBox1"
                                                    })}
                                                    class={"mx-name-groupBox1"}
                                                    style={undefined}
                                                    tabIndex={undefined}
                                                    header={t([
                                                        ExpressionProperty({
                                                            "expression": { "expr": { "type": "literal", "value": "Receta" }, "args": {} }
                                                        })
                                                    ])}
                                                    renderMode={"h5"}
                                                    collapsible={"yes"}
                                                    content={[
                                                        <$Div key="p33.MyFirstModule.Consulta_View.layoutGrid4"
                                                            $widgetId="p33.MyFirstModule.Consulta_View.layoutGrid4"
                                                            class={"mx-name-layoutGrid4 mx-layoutgrid mx-layoutgrid-fluid"}
                                                            style={undefined}
                                                            content={[
                                                                <$Div key="p33.MyFirstModule.Consulta_View.layoutGrid4$row0"
                                                                    $widgetId="p33.MyFirstModule.Consulta_View.layoutGrid4$row0"
                                                                    class={"row"}
                                                                    style={undefined}
                                                                    content={[
                                                                        <$Div key="p33.MyFirstModule.Consulta_View.layoutGrid4$row0$column0"
                                                                            $widgetId="p33.MyFirstModule.Consulta_View.layoutGrid4$row0$column0"
                                                                            class={"col-lg-9 col-md col"}
                                                                            style={undefined}
                                                                            content={[
                                                                                <$Text key="p33.MyFirstModule.Consulta_View.text1"
                                                                                    $widgetId="p33.MyFirstModule.Consulta_View.text1"
                                                                                    class={"mx-name-text1"}
                                                                                    style={undefined}
                                                                                    caption={t([
                                                                                        ExpressionProperty({
                                                                                            "expression": { "expr": { "type": "function", "name": "+", "parameters": [ { "type": "function", "name": "+", "parameters": [ { "type": "function", "name": "+", "parameters": [ { "type": "function", "name": "+", "parameters": [ { "type": "function", "name": "+", "parameters": [ { "type": "literal", "value": "Medico: " }, { "type": "variable", "variable": "currentObject", "path": "Medico" } ] }, { "type": "literal", "value": "\r\nFecha: " } ] }, { "type": "function", "name": "_format", "parameters": [ { "type": "variable", "variable": "currentObject", "path": "MyFirstModule.Receta_Consulta/MyFirstModule.Consulta/FechaConsulta" }, { "type": "literal", "value": "{\"type\":\"date\"}" } ] } ] }, { "type": "literal", "value": "\r\nReclamado: " } ] }, { "type": "function", "name": "_format", "parameters": [ { "type": "variable", "variable": "currentObject", "path": "Entregado" }, { "type": "literal", "value": "{}" } ] } ] }, "args": { "currentObject": { "widget": "p33.MyFirstModule.Consulta_View.listView1", "source": "object" } } }
                                                                                        })
                                                                                    ])}
                                                                                    renderMode={"span"} />
                                                                            ]} />,
                                                                        <$Div key="p33.MyFirstModule.Consulta_View.layoutGrid4$row0$column1"
                                                                            $widgetId="p33.MyFirstModule.Consulta_View.layoutGrid4$row0$column1"
                                                                            class={"col-lg-3 col-md col align-self-center"}
                                                                            style={undefined}
                                                                            content={[
                                                                                <$ActionButton key="p33.MyFirstModule.Consulta_View.actionButton5"
                                                                                    $widgetId="p33.MyFirstModule.Consulta_View.actionButton5"
                                                                                    buttonId={"p33.MyFirstModule.Consulta_View.actionButton5"}
                                                                                    class={"mx-name-actionButton5 pull-right"}
                                                                                    style={undefined}
                                                                                    tabIndex={undefined}
                                                                                    renderType={"button"}
                                                                                    role={undefined}
                                                                                    buttonClass={"btn-default"}
                                                                                    caption={t([
                                                                                        ExpressionProperty({
                                                                                            "expression": { "expr": { "type": "literal", "value": "Editar" }, "args": {} }
                                                                                        })
                                                                                    ])}
                                                                                    tooltip={TextProperty({
                                                                                        "value": t([
                                                                                            ""
                                                                                        ])
                                                                                    })}
                                                                                    icon={WebIconProperty({
                                                                                        "icon": { "type": "icon", "iconClass": "mx-icon-lined mx-icon-notes-paper-edit" }
                                                                                    })}
                                                                                    action={ActionProperty({
                                                                                        "action": { "type": "openPage", "argMap": { "param$Receta": { "widget": "p33.MyFirstModule.Consulta_View.listView1", "source": "object" } }, "config": { "name": "MyFirstModule/Receta_View.page.xml", "location": "modal", "resizable": true }, "disabledDuringExecution": true },
                                                                                        "abortOnServerValidation": true
                                                                                    })} />
                                                                            ]} />
                                                                    ]} />
                                                            ]} />
                                                    ]} />
                                            ]
                                        })}
                                        onClick={undefined}
                                        pageSize={10} />
                                ]}
                                hideFooter={false}
                                footer={[
                                    <$ActionButton key="p33.MyFirstModule.Consulta_View.actionButton1"
                                        $widgetId="p33.MyFirstModule.Consulta_View.actionButton1"
                                        buttonId={"p33.MyFirstModule.Consulta_View.actionButton1"}
                                        class={"mx-name-actionButton1"}
                                        style={undefined}
                                        tabIndex={undefined}
                                        renderType={"button"}
                                        role={undefined}
                                        buttonClass={"btn-primary"}
                                        caption={t([
                                            ExpressionProperty({
                                                "expression": { "expr": { "type": "literal", "value": "Save" }, "args": {} }
                                            })
                                        ])}
                                        tooltip={TextProperty({
                                            "value": t([
                                                ""
                                            ])
                                        })}
                                        icon={undefined}
                                        action={ActionProperty({
                                            "action": { "type": "saveChanges", "argMap": { "$object": { "widget": "p33.MyFirstModule.Consulta_View.dataView6", "source": "object" } }, "config": { "operationId": "z7cSjlPHylqF5IIsYVV6qA", "closePage": true }, "disabledDuringExecution": true },
                                            "abortOnServerValidation": true
                                        })} />,
                                    <$ActionButton key="p33.MyFirstModule.Consulta_View.actionButton4"
                                        $widgetId="p33.MyFirstModule.Consulta_View.actionButton4"
                                        buttonId={"p33.MyFirstModule.Consulta_View.actionButton4"}
                                        class={"mx-name-actionButton4"}
                                        style={undefined}
                                        tabIndex={undefined}
                                        renderType={"button"}
                                        role={undefined}
                                        buttonClass={"btn-default"}
                                        caption={t([
                                            ExpressionProperty({
                                                "expression": { "expr": { "type": "literal", "value": "Delete" }, "args": {} }
                                            })
                                        ])}
                                        tooltip={TextProperty({
                                            "value": t([
                                                ""
                                            ])
                                        })}
                                        icon={undefined}
                                        action={ActionProperty({
                                            "action": { "type": "deleteObject", "argMap": { "$object": { "widget": "$Consulta", "source": "object" } }, "config": { "closePage": true, "operationId": "3bx1/4doYFaJZI0tBqMxuw" }, "disabledDuringExecution": true },
                                            "abortOnServerValidation": true
                                        })} />
                                ]} />
                        ]} />
                ]} />
        ]} />
]}</PageFragment>);

export const title = t([
    "Consulta View"
]);

export const classes = "";

export const cancelChangesOperationId = "Cp3NlO7PnF+2QbJmjYdpSQ";
export const style = {};
export const content = { ...parentContent,
    "Atlas_Core.PopupLayout.Main": region$Main,
};
