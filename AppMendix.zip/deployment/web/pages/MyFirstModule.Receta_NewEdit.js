import { createElement } from "react";
const React = { createElement };

import { PageFragment } from "mendix/PageFragment";
import { ActionProperty } from "mendix/ActionProperty";
import { AssociationObjectProperty } from "mendix/AssociationObjectProperty";
import { AssociationProperty } from "mendix/AssociationProperty";
import { AttributeProperty } from "mendix/AttributeProperty";
import { DatabaseObjectListProperty } from "mendix/DatabaseObjectListProperty";
import { DerivedUniqueIdProperty } from "mendix/DerivedUniqueIdProperty";
import { ExpressionProperty } from "mendix/ExpressionProperty";
import { ListAttributeProperty } from "mendix/ListAttributeProperty";
import { TemplatedWidgetProperty } from "mendix/TemplatedWidgetProperty";
import { TextProperty } from "mendix/TextProperty";
import { ValidationProperty } from "mendix/ValidationProperty";
import { WebIconProperty } from "mendix/WebIconProperty";

import { ActionButton } from "mendix/widgets/web/ActionButton";
import * as ComboboxWidgetModule from "C:/Users/Rodrigo/Mendix/App Benavides-main_3/deployment/web/widgets/com/mendix/widget/web/combobox/Combobox.mjs";
const Combobox = Object.getOwnPropertyDescriptor(ComboboxWidgetModule, "Combobox")?.value || Object.getOwnPropertyDescriptor(ComboboxWidgetModule, "default")?.value;   
import "C:/Users/Rodrigo/Mendix/App Benavides-main_3/deployment/web/widgets/com/mendix/widget/web/combobox/Combobox.css";
import { DataView } from "mendix/widgets/web/DataView";
import { Div } from "mendix/widgets/web/Div";
import { FormGroup } from "mendix/widgets/web/FormGroup";
import { GroupBox } from "mendix/widgets/web/GroupBox";
import { ListView } from "mendix/widgets/web/ListView";
import { RadioButtonGroup } from "mendix/widgets/web/RadioButtonGroup";
import { Text } from "mendix/widgets/web/Text";
import { TextBox } from "mendix/widgets/web/TextBox";
import { addEnumerations, asPluginWidgets, t } from "mendix";

import { content as parentContent } from "../layouts/Atlas_Core.PopupLayout.js";

const { $Div, $DataView, $FormGroup, $Combobox, $TextBox, $ActionButton, $ListView, $GroupBox, $Text, $RadioButtonGroup } = asPluginWidgets({ Div, DataView, FormGroup, Combobox, TextBox, ActionButton, ListView, GroupBox, Text, RadioButtonGroup });

const region$Main = (historyId) => (<PageFragment renderKey={historyId}>{[
    <$Div key="p42.MyFirstModule.Receta_NewEdit.layoutGrid1"
        $widgetId="p42.MyFirstModule.Receta_NewEdit.layoutGrid1"
        class={"mx-name-layoutGrid1 mx-layoutgrid mx-layoutgrid-fluid container-fluid"}
        style={undefined}
        content={[
            <$Div key="p42.MyFirstModule.Receta_NewEdit.layoutGrid1$row0"
                $widgetId="p42.MyFirstModule.Receta_NewEdit.layoutGrid1$row0"
                class={"row"}
                style={undefined}
                content={[
                    <$Div key="p42.MyFirstModule.Receta_NewEdit.layoutGrid1$row0$column0"
                        $widgetId="p42.MyFirstModule.Receta_NewEdit.layoutGrid1$row0$column0"
                        class={"col-lg col-md col"}
                        style={undefined}
                        content={[
                            <$DataView key="p42.MyFirstModule.Receta_NewEdit.dataView6"
                                $widgetId="p42.MyFirstModule.Receta_NewEdit.dataView6"
                                class={"mx-name-dataView6 form-vertical"}
                                style={undefined}
                                tabIndex={undefined}
                                object={AssociationObjectProperty({
                                    "dataSourceId": "p42.18",
                                    "scope": "$Receta",
                                    "editable": true
                                })}
                                emptyMessage={TextProperty({
                                    "value": t([
                                        ""
                                    ])
                                })}
                                body={[
                                    <$FormGroup key="p42.MyFirstModule.Receta_NewEdit.comboBox1$formGroup"
                                        $widgetId="p42.MyFirstModule.Receta_NewEdit.comboBox1$formGroup"
                                        class={"mx-name-comboBox1"}
                                        style={undefined}
                                        control={[
                                            <$Combobox key="p42.MyFirstModule.Receta_NewEdit.comboBox1"
                                                $widgetId="p42.MyFirstModule.Receta_NewEdit.comboBox1"
                                                source={"context"}
                                                optionsSourceType={"association"}
                                                optionsSourceDatabaseDataSource={undefined}
                                                optionsSourceDatabaseCaptionType={"attribute"}
                                                optionsSourceDatabaseDefaultValue={undefined}
                                                attributeAssociation={AssociationProperty({
                                                    "type": "Reference",
                                                    "entity": "MyFirstModule.Receta",
                                                    "path": "",
                                                    "attribute": "MyFirstModule.Receta_Consulta",
                                                    "endpointEntity": "MyFirstModule.Consulta",
                                                    "selectableObjectsId": "p42.0",
                                                    "scope": "p42.MyFirstModule.Receta_NewEdit.dataView6",
                                                    "onChange": { "type": "doNothing", "argMap": {}, "config": {}, "disabledDuringExecution": false }
                                                })}
                                                optionsSourceAssociationDataSource={DatabaseObjectListProperty({
                                                    "dataSourceId": "p42.0",
                                                    "entity": "MyFirstModule.Consulta",
                                                    "scope": "p42.MyFirstModule.Receta_NewEdit.dataView6",
                                                    "operationId": "so9MQc9FEl6LTUaLEFnbzw",
                                                    "sort": []
                                                })}
                                                optionsSourceAssociationCaptionType={"attribute"}
                                                optionsSourceAssociationCaptionAttribute={ListAttributeProperty({
                                                    "path": "",
                                                    "entity": "MyFirstModule.Consulta",
                                                    "attribute": "Paciente",
                                                    "attributeType": "String",
                                                    "sortable": true,
                                                    "filterable": true,
                                                    "dataSourceId": "p42.0",
                                                    "isList": false
                                                })}
                                                optionsSourceAssociationCaptionExpression={undefined}
                                                optionsSourceStaticDataSource={[]}
                                                emptyOptionText={t([
                                                    ExpressionProperty({
                                                        "expression": { "expr": { "type": "literal", "value": "" }, "args": {} }
                                                    })
                                                ])}
                                                filterType={"contains"}
                                                noOptionsText={t([
                                                    ExpressionProperty({
                                                        "expression": { "expr": { "type": "literal", "value": "" }, "args": {} }
                                                    })
                                                ])}
                                                clearable={true}
                                                optionsSourceAssociationCustomContentType={"no"}
                                                optionsSourceAssociationCustomContent={undefined}
                                                optionsSourceDatabaseCustomContentType={"no"}
                                                staticDataSourceCustomContentType={"no"}
                                                showFooter={false}
                                                menuFooterContent={undefined}
                                                selectionMethod={"checkbox"}
                                                selectedItemsStyle={"text"}
                                                selectAllButton={false}
                                                selectAllButtonCaption={t([
                                                    ExpressionProperty({
                                                        "expression": { "expr": { "type": "literal", "value": "Select all" }, "args": {} }
                                                    })
                                                ])}
                                                readOnlyStyle={"bordered"}
                                                onChangeEvent={undefined}
                                                onEnterEvent={undefined}
                                                onLeaveEvent={undefined}
                                                ariaRequired={false}
                                                clearButtonAriaLabel={t([
                                                    ExpressionProperty({
                                                        "expression": { "expr": { "type": "literal", "value": "Clear selection" }, "args": {} }
                                                    })
                                                ])}
                                                removeValueAriaLabel={t([
                                                    ExpressionProperty({
                                                        "expression": { "expr": { "type": "literal", "value": "Remove value" }, "args": {} }
                                                    })
                                                ])}
                                                a11ySelectedValue={t([
                                                    ExpressionProperty({
                                                        "expression": { "expr": { "type": "literal", "value": "Selected value:" }, "args": {} }
                                                    })
                                                ])}
                                                a11yOptionsAvailable={t([
                                                    ExpressionProperty({
                                                        "expression": { "expr": { "type": "literal", "value": "Number of options available:" }, "args": {} }
                                                    })
                                                ])}
                                                a11yInstructions={t([
                                                    ExpressionProperty({
                                                        "expression": { "expr": { "type": "literal", "value": "Use up and down arrow keys to navigate. Press Enter or Space Bar keys to select." }, "args": {} }
                                                    })
                                                ])}
                                                lazyLoading={true}
                                                loadingType={"spinner"}
                                                tabIndex={undefined}
                                                id={DerivedUniqueIdProperty({
                                                    "widgetId": "p42.MyFirstModule.Receta_NewEdit.comboBox1"
                                                })} />
                                        ]}
                                        caption={t([
                                            ExpressionProperty({
                                                "expression": { "expr": { "type": "literal", "value": "Consulta" }, "args": {} }
                                            })
                                        ])}
                                        labelFor={DerivedUniqueIdProperty({
                                            "widgetId": "p42.MyFirstModule.Receta_NewEdit.comboBox1"
                                        })}
                                        width={undefined}
                                        orientation={"vertical"}
                                        hasError={ValidationProperty({
                                            "inputWidgetId": "p42.MyFirstModule.Receta_NewEdit.comboBox1"
                                        })} />,
                                    <$FormGroup key="p42.MyFirstModule.Receta_NewEdit.textBox1$formGroup"
                                        $widgetId="p42.MyFirstModule.Receta_NewEdit.textBox1$formGroup"
                                        class={"mx-name-textBox1 mx-textbox"}
                                        style={undefined}
                                        control={[
                                            <$TextBox key="p42.MyFirstModule.Receta_NewEdit.textBox1"
                                                $widgetId="p42.MyFirstModule.Receta_NewEdit.textBox1"
                                                inputValue={AttributeProperty({
                                                    "scope": "p42.MyFirstModule.Receta_NewEdit.dataView6",
                                                    "path": "",
                                                    "entity": "MyFirstModule.Receta",
                                                    "attribute": "Medico",
                                                    "onChange": { "type": "doNothing", "argMap": {}, "config": {}, "disabledDuringExecution": false },
                                                    "isList": false,
                                                    "validation": null,
                                                    "formatting": { }
                                                })}
                                                isPassword={false}
                                                placeholder={t([
                                                    ExpressionProperty({
                                                        "expression": { "expr": { "type": "literal", "value": "" }, "args": {} }
                                                    })
                                                ])}
                                                mask={""}
                                                readOnlyStyle={"control"}
                                                maxLength={200}
                                                onEnter={undefined}
                                                onLeave={undefined}
                                                onEnterKeyPress={undefined}
                                                ariaLabel={undefined}
                                                autocomplete={"on"}
                                                submitWhileEditing={false}
                                                submitDelay={300}
                                                ariaRequired={undefined}
                                                tabIndex={undefined}
                                                id={DerivedUniqueIdProperty({
                                                    "widgetId": "p42.MyFirstModule.Receta_NewEdit.textBox1"
                                                })} />
                                        ]}
                                        caption={t([
                                            ExpressionProperty({
                                                "expression": { "expr": { "type": "literal", "value": "Medico" }, "args": {} }
                                            })
                                        ])}
                                        labelFor={DerivedUniqueIdProperty({
                                            "widgetId": "p42.MyFirstModule.Receta_NewEdit.textBox1"
                                        })}
                                        width={undefined}
                                        orientation={"vertical"}
                                        hasError={ValidationProperty({
                                            "inputWidgetId": "p42.MyFirstModule.Receta_NewEdit.textBox1"
                                        })} />,
                                    <$FormGroup key="p42.MyFirstModule.Receta_NewEdit.textBox3$formGroup"
                                        $widgetId="p42.MyFirstModule.Receta_NewEdit.textBox3$formGroup"
                                        class={"mx-name-textBox3 mx-textbox"}
                                        style={undefined}
                                        control={[
                                            <$TextBox key="p42.MyFirstModule.Receta_NewEdit.textBox3"
                                                $widgetId="p42.MyFirstModule.Receta_NewEdit.textBox3"
                                                inputValue={AttributeProperty({
                                                    "scope": "p42.MyFirstModule.Receta_NewEdit.dataView6",
                                                    "path": "",
                                                    "entity": "MyFirstModule.Receta",
                                                    "attribute": "Paciente",
                                                    "onChange": { "type": "doNothing", "argMap": {}, "config": {}, "disabledDuringExecution": false },
                                                    "isList": false,
                                                    "validation": null,
                                                    "formatting": { }
                                                })}
                                                isPassword={false}
                                                placeholder={t([
                                                    ExpressionProperty({
                                                        "expression": { "expr": { "type": "literal", "value": "" }, "args": {} }
                                                    })
                                                ])}
                                                mask={""}
                                                readOnlyStyle={"control"}
                                                maxLength={200}
                                                onEnter={undefined}
                                                onLeave={undefined}
                                                onEnterKeyPress={undefined}
                                                ariaLabel={undefined}
                                                autocomplete={"on"}
                                                submitWhileEditing={false}
                                                submitDelay={300}
                                                ariaRequired={undefined}
                                                tabIndex={undefined}
                                                id={DerivedUniqueIdProperty({
                                                    "widgetId": "p42.MyFirstModule.Receta_NewEdit.textBox3"
                                                })} />
                                        ]}
                                        caption={t([
                                            ExpressionProperty({
                                                "expression": { "expr": { "type": "literal", "value": "Paciente" }, "args": {} }
                                            })
                                        ])}
                                        labelFor={DerivedUniqueIdProperty({
                                            "widgetId": "p42.MyFirstModule.Receta_NewEdit.textBox3"
                                        })}
                                        width={undefined}
                                        orientation={"vertical"}
                                        hasError={ValidationProperty({
                                            "inputWidgetId": "p42.MyFirstModule.Receta_NewEdit.textBox3"
                                        })} />,
                                    <$Div key="p42.MyFirstModule.Receta_NewEdit.layoutGrid4"
                                        $widgetId="p42.MyFirstModule.Receta_NewEdit.layoutGrid4"
                                        class={"mx-name-layoutGrid4 mx-layoutgrid mx-layoutgrid-fluid"}
                                        style={undefined}
                                        content={[
                                            <$Div key="p42.MyFirstModule.Receta_NewEdit.layoutGrid4$row0"
                                                $widgetId="p42.MyFirstModule.Receta_NewEdit.layoutGrid4$row0"
                                                class={"row"}
                                                style={undefined}
                                                content={[
                                                    <$Div key="p42.MyFirstModule.Receta_NewEdit.layoutGrid4$row0$column0"
                                                        $widgetId="p42.MyFirstModule.Receta_NewEdit.layoutGrid4$row0$column0"
                                                        class={"col-lg col-md col"}
                                                        style={undefined}
                                                        content={[
                                                            <$ActionButton key="p42.MyFirstModule.Receta_NewEdit.actionButton3"
                                                                $widgetId="p42.MyFirstModule.Receta_NewEdit.actionButton3"
                                                                buttonId={"p42.MyFirstModule.Receta_NewEdit.actionButton3"}
                                                                class={"mx-name-actionButton3 pull-left spacing-outer-bottom-medium"}
                                                                style={undefined}
                                                                tabIndex={undefined}
                                                                renderType={"button"}
                                                                role={undefined}
                                                                buttonClass={"btn-default"}
                                                                caption={t([
                                                                    ExpressionProperty({
                                                                        "expression": { "expr": { "type": "literal", "value": "Agregar Medicamento" }, "args": {} }
                                                                    })
                                                                ])}
                                                                tooltip={TextProperty({
                                                                    "value": t([
                                                                        ""
                                                                    ])
                                                                })}
                                                                icon={WebIconProperty({
                                                                    "icon": { "type": "icon", "iconClass": "mx-icon-lined mx-icon-add" }
                                                                })}
                                                                action={ActionProperty({
                                                                    "action": { "type": "callMicroflow", "argMap": { "Receta": { "widget": "$Receta", "source": "object" } }, "config": { "operationId": "211Hfi/QblKttC3iVHATyQ", "validate": "view" }, "disabledDuringExecution": true },
                                                                    "abortOnServerValidation": true
                                                                })} />
                                                        ]} />
                                                ]} />
                                        ]} />,
                                    <$Div key="p42.MyFirstModule.Receta_NewEdit.layoutGrid5"
                                        $widgetId="p42.MyFirstModule.Receta_NewEdit.layoutGrid5"
                                        class={"mx-name-layoutGrid5 mx-layoutgrid mx-layoutgrid-fluid"}
                                        style={undefined}
                                        content={[
                                            <$Div key="p42.MyFirstModule.Receta_NewEdit.layoutGrid5$row0"
                                                $widgetId="p42.MyFirstModule.Receta_NewEdit.layoutGrid5$row0"
                                                class={"row"}
                                                style={undefined}
                                                content={[
                                                    <$Div key="p42.MyFirstModule.Receta_NewEdit.layoutGrid5$row0$column0"
                                                        $widgetId="p42.MyFirstModule.Receta_NewEdit.layoutGrid5$row0$column0"
                                                        class={"col-lg col-md col"}
                                                        style={undefined}
                                                        content={[
                                                            <$ListView key="p42.MyFirstModule.Receta_NewEdit.listView1"
                                                                $widgetId="p42.MyFirstModule.Receta_NewEdit.listView1"
                                                                class={"mx-name-listView1"}
                                                                style={undefined}
                                                                listValue={DatabaseObjectListProperty({
                                                                    "dataSourceId": "p42.3",
                                                                    "entity": "MyFirstModule.Medicamento",
                                                                    "scope": "p42.MyFirstModule.Receta_NewEdit.dataView6",
                                                                    "operationId": "wYIfjl8DX1u2LgK9Zm72cw",
                                                                    "sort": [],
                                                                    "arguments": {
                                                                        "currentObject": [
                                                                            "$Receta"
                                                                        ],
                                                                        "CurrentObject": [
                                                                            "$Receta"
                                                                        ]
                                                                    },
                                                                    "constraints": { "type": "function", "name": "=", "parameters": [ { "type": "attribute", "attribute": "MyFirstModule.Medicamento_Receta", "context": "MyFirstModule.Medicamento", "attributeType": "ObjectReference" }, { "type": "variable", "name": "currentObject" } ] }
                                                                })}
                                                                itemTemplate={TemplatedWidgetProperty({
                                                                    "dataSourceId": "p42.3",
                                                                    "editable": false,
                                                                    "children": () => [
                                                                        <$GroupBox key="p42.MyFirstModule.Receta_NewEdit.groupBox1"
                                                                            $widgetId="p42.MyFirstModule.Receta_NewEdit.groupBox1"
                                                                            id={DerivedUniqueIdProperty({
                                                                                "widgetId": "p42.MyFirstModule.Receta_NewEdit.groupBox1"
                                                                            })}
                                                                            class={"mx-name-groupBox1"}
                                                                            style={undefined}
                                                                            tabIndex={undefined}
                                                                            header={t([
                                                                                ExpressionProperty({
                                                                                    "expression": { "expr": { "type": "variable", "variable": "currentObject", "path": "Titulo" }, "args": { "currentObject": { "widget": "p42.MyFirstModule.Receta_NewEdit.listView1", "source": "object" } } }
                                                                                })
                                                                            ])}
                                                                            renderMode={"h5"}
                                                                            collapsible={"notInitially"}
                                                                            content={[
                                                                                <$Div key="p42.MyFirstModule.Receta_NewEdit.layoutGrid3"
                                                                                    $widgetId="p42.MyFirstModule.Receta_NewEdit.layoutGrid3"
                                                                                    class={"mx-name-layoutGrid3 mx-layoutgrid mx-layoutgrid-fluid"}
                                                                                    style={undefined}
                                                                                    content={[
                                                                                        <$Div key="p42.MyFirstModule.Receta_NewEdit.layoutGrid3$row0"
                                                                                            $widgetId="p42.MyFirstModule.Receta_NewEdit.layoutGrid3$row0"
                                                                                            class={"row"}
                                                                                            style={undefined}
                                                                                            content={[
                                                                                                <$Div key="p42.MyFirstModule.Receta_NewEdit.layoutGrid3$row0$column0"
                                                                                                    $widgetId="p42.MyFirstModule.Receta_NewEdit.layoutGrid3$row0$column0"
                                                                                                    class={"col-lg-9 col-md col"}
                                                                                                    style={undefined}
                                                                                                    content={[
                                                                                                        <$Text key="p42.MyFirstModule.Receta_NewEdit.text1"
                                                                                                            $widgetId="p42.MyFirstModule.Receta_NewEdit.text1"
                                                                                                            class={"mx-name-text1"}
                                                                                                            style={undefined}
                                                                                                            caption={t([
                                                                                                                ExpressionProperty({
                                                                                                                    "expression": { "expr": { "type": "function", "name": "+", "parameters": [ { "type": "function", "name": "+", "parameters": [ { "type": "function", "name": "+", "parameters": [ { "type": "function", "name": "+", "parameters": [ { "type": "function", "name": "+", "parameters": [ { "type": "literal", "value": "Dosis: " }, { "type": "variable", "variable": "currentObject", "path": "Dosis" } ] }, { "type": "literal", "value": "\r\nFrecuencia: " } ] }, { "type": "variable", "variable": "currentObject", "path": "Frecuencia" } ] }, { "type": "literal", "value": "\r\nDuración: " } ] }, { "type": "variable", "variable": "currentObject", "path": "Duracion" } ] }, "args": { "currentObject": { "widget": "p42.MyFirstModule.Receta_NewEdit.listView1", "source": "object" } } }
                                                                                                                })
                                                                                                            ])}
                                                                                                            renderMode={"span"} />
                                                                                                    ]} />,
                                                                                                <$Div key="p42.MyFirstModule.Receta_NewEdit.layoutGrid3$row0$column1"
                                                                                                    $widgetId="p42.MyFirstModule.Receta_NewEdit.layoutGrid3$row0$column1"
                                                                                                    class={"col-lg-3 col-md col align-self-center"}
                                                                                                    style={undefined}
                                                                                                    content={[
                                                                                                        <$ActionButton key="p42.MyFirstModule.Receta_NewEdit.actionButton4"
                                                                                                            $widgetId="p42.MyFirstModule.Receta_NewEdit.actionButton4"
                                                                                                            buttonId={"p42.MyFirstModule.Receta_NewEdit.actionButton4"}
                                                                                                            class={"mx-name-actionButton4 pull-right"}
                                                                                                            style={undefined}
                                                                                                            tabIndex={undefined}
                                                                                                            renderType={"button"}
                                                                                                            role={undefined}
                                                                                                            buttonClass={"btn-default"}
                                                                                                            caption={t([
                                                                                                                ExpressionProperty({
                                                                                                                    "expression": { "expr": { "type": "literal", "value": "Editar" }, "args": {} }
                                                                                                                })
                                                                                                            ])}
                                                                                                            tooltip={TextProperty({
                                                                                                                "value": t([
                                                                                                                    ""
                                                                                                                ])
                                                                                                            })}
                                                                                                            icon={WebIconProperty({
                                                                                                                "icon": { "type": "icon", "iconClass": "mx-icon-lined mx-icon-notes-paper-edit" }
                                                                                                            })}
                                                                                                            action={ActionProperty({
                                                                                                                "action": { "type": "openPage", "argMap": { "param$Medicamento": { "widget": "p42.MyFirstModule.Receta_NewEdit.listView1", "source": "object" } }, "config": { "name": "MyFirstModule/Medicamento_View.page.xml", "location": "modal", "resizable": true }, "disabledDuringExecution": true },
                                                                                                                "abortOnServerValidation": true
                                                                                                            })} />
                                                                                                    ]} />
                                                                                            ]} />
                                                                                    ]} />,
                                                                                <$Div key="p42.MyFirstModule.Receta_NewEdit.layoutGrid2"
                                                                                    $widgetId="p42.MyFirstModule.Receta_NewEdit.layoutGrid2"
                                                                                    class={"mx-name-layoutGrid2 mx-layoutgrid mx-layoutgrid-fluid"}
                                                                                    style={undefined}
                                                                                    content={[
                                                                                        <$Div key="p42.MyFirstModule.Receta_NewEdit.layoutGrid2$row0"
                                                                                            $widgetId="p42.MyFirstModule.Receta_NewEdit.layoutGrid2$row0"
                                                                                            class={"row"}
                                                                                            style={undefined}
                                                                                            content={[
                                                                                                <$Div key="p42.MyFirstModule.Receta_NewEdit.layoutGrid2$row0$column0"
                                                                                                    $widgetId="p42.MyFirstModule.Receta_NewEdit.layoutGrid2$row0$column0"
                                                                                                    class={"col-lg-auto col-md-auto col-auto"}
                                                                                                    style={undefined}
                                                                                                    content={[
                                                                                                        <$Text key="p42.MyFirstModule.Receta_NewEdit.text2"
                                                                                                            $widgetId="p42.MyFirstModule.Receta_NewEdit.text2"
                                                                                                            class={"mx-name-text2 spacing-inner-top-medium"}
                                                                                                            style={undefined}
                                                                                                            caption={t([
                                                                                                                ExpressionProperty({
                                                                                                                    "expression": { "expr": { "type": "function", "name": "+", "parameters": [ { "type": "literal", "value": "Instrucciones: " }, { "type": "variable", "variable": "currentObject", "path": "Instrucciones" } ] }, "args": { "currentObject": { "widget": "p42.MyFirstModule.Receta_NewEdit.listView1", "source": "object" } } }
                                                                                                                })
                                                                                                            ])}
                                                                                                            renderMode={"span"} />
                                                                                                    ]} />
                                                                                            ]} />
                                                                                    ]} />
                                                                            ]} />
                                                                    ]
                                                                })}
                                                                onClick={undefined}
                                                                pageSize={10} />
                                                        ]} />
                                                ]} />
                                        ]} />,
                                    <$FormGroup key="p42.MyFirstModule.Receta_NewEdit.radioButtons1$formGroup"
                                        $widgetId="p42.MyFirstModule.Receta_NewEdit.radioButtons1$formGroup"
                                        class={"mx-name-radioButtons1 mx-radiobuttons inline"}
                                        style={undefined}
                                        control={[
                                            <$RadioButtonGroup key="p42.MyFirstModule.Receta_NewEdit.radioButtons1"
                                                $widgetId="p42.MyFirstModule.Receta_NewEdit.radioButtons1"
                                                value={AttributeProperty({
                                                    "scope": "p42.MyFirstModule.Receta_NewEdit.dataView6",
                                                    "path": "",
                                                    "entity": "MyFirstModule.Receta",
                                                    "attribute": "Entregado",
                                                    "onChange": { "type": "doNothing", "argMap": {}, "config": {}, "disabledDuringExecution": false },
                                                    "isList": false,
                                                    "validation": null
                                                })}
                                                readOnlyStyle={"control"}
                                                onEnter={undefined}
                                                onLeave={undefined}
                                                ariaLabel={undefined}
                                                ariaRequired={undefined}
                                                tabIndex={undefined}
                                                id={DerivedUniqueIdProperty({
                                                    "widgetId": "p42.MyFirstModule.Receta_NewEdit.radioButtons1"
                                                })} />
                                        ]}
                                        caption={t([
                                            ExpressionProperty({
                                                "expression": { "expr": { "type": "literal", "value": "Entregado" }, "args": {} }
                                            })
                                        ])}
                                        labelFor={DerivedUniqueIdProperty({
                                            "widgetId": "p42.MyFirstModule.Receta_NewEdit.radioButtons1"
                                        })}
                                        width={undefined}
                                        orientation={"vertical"}
                                        hasError={ValidationProperty({
                                            "inputWidgetId": "p42.MyFirstModule.Receta_NewEdit.radioButtons1"
                                        })} />
                                ]}
                                hideFooter={false}
                                footer={[
                                    <$ActionButton key="p42.MyFirstModule.Receta_NewEdit.actionButton1"
                                        $widgetId="p42.MyFirstModule.Receta_NewEdit.actionButton1"
                                        buttonId={"p42.MyFirstModule.Receta_NewEdit.actionButton1"}
                                        class={"mx-name-actionButton1"}
                                        style={undefined}
                                        tabIndex={undefined}
                                        renderType={"button"}
                                        role={undefined}
                                        buttonClass={"btn-primary"}
                                        caption={t([
                                            ExpressionProperty({
                                                "expression": { "expr": { "type": "literal", "value": "Save" }, "args": {} }
                                            })
                                        ])}
                                        tooltip={TextProperty({
                                            "value": t([
                                                ""
                                            ])
                                        })}
                                        icon={undefined}
                                        action={ActionProperty({
                                            "action": { "type": "saveChanges", "argMap": { "$object": { "widget": "p42.MyFirstModule.Receta_NewEdit.dataView6", "source": "object" } }, "config": { "operationId": "T4rrYfN0yVGn+yJg6Wx0gw", "closePage": true }, "disabledDuringExecution": true },
                                            "abortOnServerValidation": true
                                        })} />,
                                    <$ActionButton key="p42.MyFirstModule.Receta_NewEdit.actionButton2"
                                        $widgetId="p42.MyFirstModule.Receta_NewEdit.actionButton2"
                                        buttonId={"p42.MyFirstModule.Receta_NewEdit.actionButton2"}
                                        class={"mx-name-actionButton2"}
                                        style={undefined}
                                        tabIndex={undefined}
                                        renderType={"button"}
                                        role={undefined}
                                        buttonClass={"btn-default"}
                                        caption={t([
                                            ExpressionProperty({
                                                "expression": { "expr": { "type": "literal", "value": "Cancel" }, "args": {} }
                                            })
                                        ])}
                                        tooltip={TextProperty({
                                            "value": t([
                                                ""
                                            ])
                                        })}
                                        icon={undefined}
                                        action={ActionProperty({
                                            "action": { "type": "cancelChanges", "argMap": {}, "config": { "operationId": "aB9ViT1QO1KD1/OKOpdWlQ", "closePage": true }, "disabledDuringExecution": true },
                                            "abortOnServerValidation": true
                                        })} />
                                ]} />
                        ]} />
                ]} />
        ]} />
]}</PageFragment>);

export const title = t([
    "Crear Receta"
]);

export const classes = "";

export const cancelChangesOperationId = "BpwawEeJJlOm0B81W3ZU/w";
export const style = {};
export const content = { ...parentContent,
    "Atlas_Core.PopupLayout.Main": region$Main,
};
